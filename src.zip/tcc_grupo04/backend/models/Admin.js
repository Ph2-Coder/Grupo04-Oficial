const mongoose = require('mongoose');

const AdminSchema = new mongoose.Schema({
  nome: {
    type: String,
    required: [true, 'O nome é obrigatório'],
    trim: true
  },
  email: {
    type: String,
    required: [true, 'O e-mail é obrigatório'],
    unique: true,
    trim: true,
    lowercase: true
  },
  senha: {
    type: String,
    required: [true, 'A senha é obrigatória'],
    minlength: 6
  },
  avatar: {
    type: String,
    default: null
  },
  ativo: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true,
  collection: 'Adm'
});

module.exports = mongoose.model('Admin', AdminSchema);