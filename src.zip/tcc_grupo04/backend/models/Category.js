const mongoose = require('mongoose');

const CategorySchema = new mongoose.Schema({
  nome: {
    type: String,
    required: [true, 'O nome da categoria é obrigatório'],
    trim: true,
    unique: true
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Category', CategorySchema);