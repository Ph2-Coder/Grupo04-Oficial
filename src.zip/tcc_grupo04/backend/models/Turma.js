const mongoose = require('mongoose');

const TurmaSchema = new mongoose.Schema({
  nome: {
    type: String,
    required: [true, 'O nome da turma é obrigatório'],
    trim: true,
    unique: true
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Turma', TurmaSchema);