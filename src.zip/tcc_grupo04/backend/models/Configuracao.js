const mongoose = require('mongoose');

// Guarda as configurações gerais do sistema (existe um único documento, chave "geral")
const ConfiguracaoSchema = new mongoose.Schema({
  chave: {
    type: String,
    default: 'geral',
    unique: true
  },
  eventoAtivo: {
    type: Boolean,
    default: false
  },
  eventoAtualizadoEm: {
    type: Date,
    default: null
  },
  eventoAtualizadoPor: {
    type: String,
    default: null
  }
}, {
  timestamps: true,
  collection: 'configuracoes'
});

module.exports = mongoose.model('Configuracao', ConfiguracaoSchema);