const mongoose = require('mongoose');

const MessageSchema = new mongoose.Schema({
  userId: {
    type: mongoose.Schema.Types.ObjectId,
    required: true,
    ref: 'User'
  },
  remetenteRole: {
    type: String,
    enum: ['user', 'admin'],
    required: true
  },
  remetenteId: {
    type: mongoose.Schema.Types.ObjectId,
    required: true
  },
  remetenteNome: {
    type: String
  },
  tipo: {
    type: String,
    enum: ['texto', 'perda'],
    default: 'texto'
  },
  conteudo: {
    type: String,
    required: true,
    trim: true
  },
  itemPerdido: {
    nome: { type: String, default: null },
    descricao: { type: String, default: null },
    local: { type: String, default: null },
    imagem: {
      data: { type: String, default: null },
      contentType: { type: String, default: null }
    }
  },
  lida: {
    type: Boolean,
    default: false
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Message', MessageSchema);