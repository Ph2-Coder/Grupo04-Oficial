const mongoose = require('mongoose');

const UserSchema = new mongoose.Schema({
  nome: {
    type: String,
    required: [true, 'O nome é obrigatório'],
    trim: true
  },
  email: {
    type: String,
    required: [true, 'O e-mail é obrigatório'],
    unique: true,
    trim: true,
    lowercase: true
  },
  senha: {
    type: String,
    required: [true, 'A senha é obrigatória'],
    minlength: 6
  },
  categoria: {
    type: String,
    enum: ['Funcionário', 'Aluno', 'Visitante'],
    required: [true, 'A categoria é obrigatória']
  },
  turma: {
    type: String,
    default: null
  },
  avatar: {
    type: String,
    default: null
  },
  ativo: {
    type: Boolean,
    default: true
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('User', UserSchema);