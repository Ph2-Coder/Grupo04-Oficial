const mongoose = require('mongoose');

const ItemSchema = new mongoose.Schema({
  nome: {
    type: String,
    required: [true, 'O nome do item é obrigatório'],
    trim: true
  },
  descricao: {
    type: String,
    trim: true
  },
  tipo: {
    type: String,
    enum: ['Achado', 'Perdido'],
    default: 'Achado'
  },
  categoria: {
    type: String,
    default: 'Outros'
  },
  status: {
    type: String,
    enum: ['Pendente', 'Devolvido'],
    default: 'Pendente'
  },
  local: {
    type: String,
    trim: true
  },
  dataRegistro: {
    type: Date,
    default: Date.now
  },
  imagem: {
    data: String,       // imagem em Base64
    contentType: String // ex: "image/png"
  },
  retiradoPor: {
    userId: { type: String, default: null },
    nome: { type: String, default: null },
    email: { type: String, default: null },
    role: { type: String, default: null } // 'user' ou 'admin'
  }
}, {
  timestamps: true
});

module.exports = mongoose.model('Item', ItemSchema);