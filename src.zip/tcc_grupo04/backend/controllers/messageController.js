const Message = require('../models/Message');
const User = require('../models/User');
const Admin = require('../models/Admin');

// Enviar mensagem de texto normal
const sendMessage = async (req, res) => {
  try {
    const { conteudo, userId } = req.body;

    if (!conteudo || !conteudo.trim()) {
      return res.status(400).json({ message: 'A mensagem não pode estar vazia.' });
    }

    let remetenteNome = '';
    let idConversa;

    if (req.user.role === 'admin') {
      if (!userId) {
        return res.status(400).json({ message: 'Selecione um usuário para enviar a mensagem.' });
      }
      const admin = await Admin.findById(req.user.id);
      remetenteNome = admin?.nome || 'Administrador';
      idConversa = userId;
    } else {
      // Verifica se o admin já iniciou a conversa com este usuário
      const adminIniciou = await Message.findOne({
        userId: req.user.id,
        remetenteRole: 'admin'
      });

      // Se o admin não iniciou, o usuário precisa ter relatado um item perdido antes
      if (!adminIniciou) {
        const jaRelatou = await Message.findOne({ userId: req.user.id, tipo: 'perda' });
        if (!jaRelatou) {
          return res.status(400).json({
            message: 'Preencha o formulário de item perdido antes de enviar mensagens.'
          });
        }

        // E também precisa aguardar a resposta do admin após o relato
        const adminRespondeuAposRelato = await Message.findOne({
          userId: req.user.id,
          remetenteRole: 'admin'
        });
        if (!adminRespondeuAposRelato) {
          return res.status(400).json({
            message: 'Aguarde a resposta do administrador para continuar a conversa.'
          });
        }
      }

      const user = await User.findById(req.user.id);
      remetenteNome = user?.nome || 'Usuário';
      idConversa = req.user.id;
    }

    const mensagem = await Message.create({
      userId: idConversa,
      remetenteRole: req.user.role,
      remetenteId: req.user.id,
      remetenteNome,
      tipo: 'texto',
      conteudo: conteudo.trim()
    });

    res.status(201).json(mensagem);

  } catch (error) {
    res.status(500).json({ message: 'Erro no servidor.', error: error.message });
  }
};

// Usuário comum: relatar um item perdido (primeira mensagem da conversa)
const reportarPerda = async (req, res) => {
  try {
    if (req.user.role === 'admin') {
      return res.status(400).json({ message: 'Apenas usuários podem relatar itens perdidos.' });
    }

    const { nome, descricao, local } = req.body;

    if (!nome || !nome.trim()) {
      return res.status(400).json({ message: 'Informe o nome do item perdido.' });
    }

    const user = await User.findById(req.user.id);

    let imagem = { data: null, contentType: null };
    if (req.file) {
      imagem = {
        data: req.file.buffer.toString('base64'),
        contentType: req.file.mimetype
      };
    }

    const mensagem = await Message.create({
      userId: req.user.id,
      remetenteRole: 'user',
      remetenteId: req.user.id,
      remetenteNome: user?.nome || 'Usuário',
      tipo: 'perda',
      conteudo: `📋 Relatou um item perdido: ${nome.trim()}`,
      itemPerdido: {
        nome: nome.trim(),
        descricao: descricao?.trim() || null,
        local: local?.trim() || null,
        imagem
      }
    });

    res.status(201).json(mensagem);

  } catch (error) {
    res.status(500).json({ message: 'Erro no servidor.', error: error.message });
  }
};

// Usuário comum: buscar a própria conversa (com o admin)
const getMinhasMensagens = async (req, res) => {
  try {
    if (req.user.role === 'admin') {
      return res.status(400).json({ message: 'Use a rota de conversas para administradores.' });
    }

    const mensagens = await Message.find({ userId: req.user.id }).sort({ createdAt: 1 });

    await Message.updateMany(
      { userId: req.user.id, remetenteRole: 'admin', lida: false },
      { lida: true }
    );

    res.status(200).json(mensagens);
  } catch (error) {
    res.status(500).json({ message: 'Erro no servidor.', error: error.message });
  }
};

// Admin: listar todas as conversas (uma por usuário)
const getConversas = async (req, res) => {
  try {
    const conversas = await Message.aggregate([
      { $sort: { createdAt: -1 } },
      {
        $group: {
          _id: '$userId',
          ultimaMensagem: { $first: '$conteudo' },
          ultimaData: { $first: '$createdAt' },
          naoLidas: {
            $sum: {
              $cond: [
                { $and: [{ $eq: ['$remetenteRole', 'user'] }, { $eq: ['$lida', false] }] },
                1,
                0
              ]
            }
          }
        }
      },
      { $sort: { ultimaData: -1 } }
    ]);

    const conversasComUsuario = await Promise.all(
      conversas.map(async (c) => {
        const user = await User.findById(c._id).select('nome email avatar');
        return {
          userId: c._id,
          nome: user?.nome || 'Usuário removido',
          email: user?.email || '',
          avatar: user?.avatar || null,
          ultimaMensagem: c.ultimaMensagem,
          ultimaData: c.ultimaData,
          naoLidas: c.naoLidas
        };
      })
    );

    res.status(200).json(conversasComUsuario);
  } catch (error) {
    res.status(500).json({ message: 'Erro no servidor.', error: error.message });
  }
};

// Admin: buscar mensagens de uma conversa específica
const getConversa = async (req, res) => {
  try {
    const { userId } = req.params;

    const mensagens = await Message.find({ userId }).sort({ createdAt: 1 });

    await Message.updateMany(
      { userId, remetenteRole: 'user', lida: false },
      { lida: true }
    );

    res.status(200).json(mensagens);
  } catch (error) {
    res.status(500).json({ message: 'Erro no servidor.', error: error.message });
  }
};

// Admin: excluir uma conversa inteira (todas as mensagens com um usuário)
const deleteConversa = async (req, res) => {
  try {
    const { userId } = req.params;

    const resultado = await Message.deleteMany({ userId });

    res.status(200).json({
      message: 'Conversa excluída com sucesso.',
      userId,
      quantidadeExcluida: resultado.deletedCount
    });
  } catch (error) {
    res.status(500).json({ message: 'Erro no servidor.', error: error.message });
  }
};

module.exports = {
  sendMessage,
  reportarPerda,
  getMinhasMensagens,
  getConversas,
  getConversa,
  deleteConversa
};