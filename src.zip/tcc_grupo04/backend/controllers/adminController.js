const User = require('../models/User');
const Admin = require('../models/Admin');

const loginUser = async (req, res) => {
  try {
    const { email, senha } = req.body;
    const emailFormatted = email.toLowerCase().trim();

    // Primeiro tenta achar na collection de 'users'
    let user = await User.findOne({ email: emailFormatted });

    // Se não achar, tenta achar na collection 'adm'
    if (!user) {
      user = await Admin.findOne({ email: emailFormatted });
    }

    // Se não achar em nenhuma das duas:
    if (!user) {
      return res.status(400).json({ message: 'Usuário não encontrado.' });
    }

    const senhaCorreta = await bcrypt.compare(senha, user.senha);
    if (!senhaCorreta) {
      return res.status(400).json({ message: 'Senha incorreta.' });
    }

    const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET || 'secreto', { expiresIn: '1d' });

    res.status(200).json({
      _id: user._id,
      nome: user.nome,
      email: user.email,
      role: user.role || 'user',
      token
    });

  } catch (error) {
    res.status(500).json({ message: 'Erro no servidor.', error: error.message });
  }
};