const Turma = require('../models/Turma');
const User = require('../models/User');

// Listar todas as turmas (rota pública — usada na tela de cadastro)
const getTurmas = async (req, res) => {
  try {
    const turmas = await Turma.find().sort({ nome: 1 });
    res.status(200).json(turmas);
  } catch (error) {
    res.status(500).json({ message: 'Erro no servidor.', error: error.message });
  }
};

// Criar nova turma (somente admin)
const createTurma = async (req, res) => {
  try {
    const { nome } = req.body;

    if (!nome || !nome.trim()) {
      return res.status(400).json({ message: 'O nome da turma é obrigatório.' });
    }

    const existe = await Turma.findOne({ nome: nome.trim() });
    if (existe) {
      return res.status(400).json({ message: 'Essa turma já existe.' });
    }

    const turma = await Turma.create({ nome: nome.trim() });
    res.status(201).json(turma);

  } catch (error) {
    res.status(500).json({ message: 'Erro no servidor.', error: error.message });
  }
};

// Excluir turma (somente admin)
const deleteTurma = async (req, res) => {
  try {
    const { id } = req.params;

    const turma = await Turma.findById(id);
    if (!turma) {
      return res.status(404).json({ message: 'Turma não encontrada.' });
    }

    const emUso = await User.countDocuments({ turma: turma.nome });
    if (emUso > 0) {
      return res.status(400).json({
        message: `Essa turma está sendo usada por ${emUso} aluno(s) e não pode ser excluída.`
      });
    }

    await turma.deleteOne();
    res.status(200).json({ message: 'Turma excluída com sucesso.', id });

  } catch (error) {
    res.status(500).json({ message: 'Erro no servidor.', error: error.message });
  }
};

module.exports = { getTurmas, createTurma, deleteTurma };