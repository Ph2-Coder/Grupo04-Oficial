const Configuracao = require('../models/Configuracao');
const Admin = require('../models/Admin');

// Busca a configuração geral (cria com os valores padrão se ainda não existir)
const obterConfig = async () => {
  return Configuracao.findOneAndUpdate(
    { chave: 'geral' },
    { $setOnInsert: { eventoAtivo: false } },
    { upsert: true, returnDocument: 'after' }
  );
};

// Monta a resposta: o nome de quem alterou só vai para administradores
const montarResposta = (config, ehAdmin) => {
  const resposta = {
    eventoAtivo: config.eventoAtivo,
    atualizadoEm: config.eventoAtualizadoEm
  };

  if (ehAdmin) {
    resposta.atualizadoPor = config.eventoAtualizadoPor;
  }

  return resposta;
};

// Qualquer usuário logado pode consultar (para saber se o modo evento está ativo)
const getConfig = async (req, res) => {
  try {
    const config = await obterConfig();
    res.status(200).json(montarResposta(config, req.user.role === 'admin'));
  } catch (error) {
    res.status(500).json({ message: 'Erro no servidor.', error: error.message });
  }
};

// Somente administradores ativam ou encerram o modo evento
const updateConfig = async (req, res) => {
  try {
    const { eventoAtivo } = req.body;

    if (typeof eventoAtivo !== 'boolean') {
      return res.status(400).json({ message: 'Valor inválido para o modo evento.' });
    }

    const admin = await Admin.findById(req.user.id).select('nome');

    const config = await Configuracao.findOneAndUpdate(
      { chave: 'geral' },
      {
        eventoAtivo,
        eventoAtualizadoEm: new Date(),
        eventoAtualizadoPor: admin?.nome || 'Administrador'
      },
      { upsert: true, returnDocument: 'after' }
    );

    res.status(200).json(montarResposta(config, true));
  } catch (error) {
    res.status(500).json({ message: 'Erro no servidor.', error: error.message });
  }
};

module.exports = { obterConfig, getConfig, updateConfig };