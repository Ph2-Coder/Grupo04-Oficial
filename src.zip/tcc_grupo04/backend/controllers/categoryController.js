const Category = require('../models/Category');
const Item = require('../models/Item');

// Listar todas as categorias
const getCategories = async (req, res) => {
  try {
    const categorias = await Category.find().sort({ nome: 1 });
    res.status(200).json(categorias);
  } catch (error) {
    res.status(500).json({ message: 'Erro no servidor.', error: error.message });
  }
};

// Criar nova categoria (somente admin)
const createCategory = async (req, res) => {
  try {
    const { nome } = req.body;

    if (!nome || !nome.trim()) {
      return res.status(400).json({ message: 'O nome da categoria é obrigatório.' });
    }

    const existe = await Category.findOne({ nome: nome.trim() });
    if (existe) {
      return res.status(400).json({ message: 'Essa categoria já existe.' });
    }

    const categoria = await Category.create({ nome: nome.trim() });
    res.status(201).json(categoria);

  } catch (error) {
    res.status(500).json({ message: 'Erro no servidor.', error: error.message });
  }
};

// Excluir categoria (somente admin)
const deleteCategory = async (req, res) => {
  try {
    const { id } = req.params;

    const categoria = await Category.findById(id);
    if (!categoria) {
      return res.status(404).json({ message: 'Categoria não encontrada.' });
    }

    // Verifica se existem itens usando essa categoria antes de excluir
    const emUso = await Item.countDocuments({ categoria: categoria.nome });
    if (emUso > 0) {
      return res.status(400).json({
        message: `Essa categoria está sendo usada em ${emUso} item(ns) e não pode ser excluída.`
      });
    }

    await categoria.deleteOne();
    res.status(200).json({ message: 'Categoria excluída com sucesso.', id });

  } catch (error) {
    res.status(500).json({ message: 'Erro no servidor.', error: error.message });
  }
};

module.exports = { getCategories, createCategory, deleteCategory };