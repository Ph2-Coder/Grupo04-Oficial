const Item = require('../models/Item');
const { obterConfig } = require('./configController');

// Pares fixos: cada tipo tem um status correspondente
const STATUS_POR_TIPO = { Perdido: 'Pendente', Achado: 'Devolvido' };
const TIPO_POR_STATUS = { Pendente: 'Perdido', Devolvido: 'Achado' };

// Data de hoje segundo o servidor, no fuso de Brasília (formato YYYY-MM-DD)
const hojeNoServidor = () =>
  new Intl.DateTimeFormat('en-CA', {
    timeZone: 'America/Sao_Paulo',
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  }).format(new Date());

// A data precisa ser válida e não pode estar no futuro
const validarDataRegistro = (dataRegistro) => {
  const dia = String(dataRegistro).slice(0, 10);

  if (!/^\d{4}-\d{2}-\d{2}$/.test(dia) || isNaN(new Date(dia).getTime())) {
    return 'Data de registro inválida.';
  }

  if (dia > hojeNoServidor()) {
    return 'A data de registro não pode estar no futuro.';
  }

  return null;
};

// Informa ao frontend qual é a data de hoje no servidor
const getDataServidor = (req, res) => {
  res.status(200).json({ hoje: hojeNoServidor() });
};

// Criar novo item: sempre nasce como Perdido / Pendente
const createItem = async (req, res) => {
  try {
    const { nome, descricao, categoria, local, dataRegistro } = req.body;

    if (!nome) {
      return res.status(400).json({ message: 'O nome do item é obrigatório.' });
    }

    if (dataRegistro) {
      const erroData = validarDataRegistro(dataRegistro);
      if (erroData) {
        return res.status(400).json({ message: erroData });
      }
    }

    let imagem = null;
    if (req.file) {
      imagem = {
        data: req.file.buffer.toString('base64'),
        contentType: req.file.mimetype
      };
    }

    const item = await Item.create({
      nome,
      descricao,
      tipo: 'Perdido',
      categoria,
      status: 'Pendente',
      local,
      dataRegistro: dataRegistro || Date.now(),
      imagem
    });

    res.status(201).json(item);

  } catch (error) {
    res.status(500).json({ message: 'Erro no servidor.', error: error.message });
  }
};

// Listar itens
// - Admin: vê tudo, inclusive quem retirou
// - Usuário comum: só vê itens Devolvidos, a menos que o MODO EVENTO esteja ativo
//   (aí vê todos). Em nenhum caso recebe a informação de quem retirou o item.
const getItems = async (req, res) => {
  try {
    if (req.user.role === 'admin') {
      const items = await Item.find().sort({ createdAt: -1 });
      return res.status(200).json(items);
    }

    const config = await obterConfig();
    const filtro = config.eventoAtivo ? {} : { status: 'Devolvido' };

    const items = await Item.find(filtro)
      .select('-retiradoPor')
      .sort({ createdAt: -1 });

    res.status(200).json(items);
  } catch (error) {
    res.status(500).json({ message: 'Erro no servidor.', error: error.message });
  }
};

// Atualizar item existente
const updateItem = async (req, res) => {
  try {
    const { id } = req.params;
    const { nome, descricao, tipo, categoria, status, local, dataRegistro, retiradoPor } = req.body;

    const item = await Item.findById(id);
    if (!item) {
      return res.status(404).json({ message: 'Item não encontrado.' });
    }

    // Só valida a data se ela foi alterada (não trava a edição de itens antigos)
    if (dataRegistro) {
      const diaAtual = item.dataRegistro
        ? new Date(item.dataRegistro).toISOString().slice(0, 10)
        : null;
      const diaEnviado = String(dataRegistro).slice(0, 10);

      if (diaEnviado !== diaAtual) {
        const erroData = validarDataRegistro(dataRegistro);
        if (erroData) {
          return res.status(400).json({ message: erroData });
        }
      }
    }

    item.nome = nome ?? item.nome;
    item.descricao = descricao ?? item.descricao;
    item.categoria = categoria ?? item.categoria;
    item.local = local ?? item.local;
    item.dataRegistro = dataRegistro || item.dataRegistro;

    // 1) Primeiro resolve quem retirou o item (vem como JSON string via FormData)
    if (retiradoPor !== undefined) {
      if (!retiradoPor || retiradoPor === 'null') {
        item.retiradoPor = { userId: null, nome: null, email: null, role: null };
      } else {
        try {
          const parsed = JSON.parse(retiradoPor);
          item.retiradoPor = {
            userId: parsed.userId || null,
            nome: parsed.nome || null,
            email: parsed.email || null,
            role: parsed.role || null
          };
        } catch (e) {
          // Ignora se vier em formato inválido
        }
      }
    }

    // 2) Depois define tipo e status
    if (item.retiradoPor?.userId) {
      // Item retirado por alguém: travado em Achado / Devolvido
      item.tipo = 'Achado';
      item.status = 'Devolvido';
    } else if (tipo !== undefined && tipo !== item.tipo && STATUS_POR_TIPO[tipo]) {
      // Sem retirada: tipo e status andam juntos
      item.tipo = tipo;
      item.status = STATUS_POR_TIPO[tipo];
    } else if (status !== undefined && status !== item.status && TIPO_POR_STATUS[status]) {
      item.status = status;
      item.tipo = TIPO_POR_STATUS[status];
    }

    // Só troca a imagem se uma nova foi enviada
    if (req.file) {
      item.imagem = {
        data: req.file.buffer.toString('base64'),
        contentType: req.file.mimetype
      };
    }

    await item.save();

    res.status(200).json(item);

  } catch (error) {
    res.status(500).json({ message: 'Erro no servidor.', error: error.message });
  }
};

// Deletar item
const deleteItem = async (req, res) => {
  try {
    const { id } = req.params;

    const item = await Item.findById(id);
    if (!item) {
      return res.status(404).json({ message: 'Item não encontrado.' });
    }

    await item.deleteOne();

    res.status(200).json({ message: 'Item excluído com sucesso.', id });

  } catch (error) {
    res.status(500).json({ message: 'Erro no servidor.', error: error.message });
  }
};

module.exports = { createItem, getItems, updateItem, deleteItem, getDataServidor };