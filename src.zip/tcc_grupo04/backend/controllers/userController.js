const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Admin = require('../models/Admin');
const Turma = require('../models/Turma');

const AVATARES_PERMITIDOS = [
  'fox', 'cat', 'dog', 'panda', 'lion', 'koala',
  'owl', 'penguin', 'rabbit', 'bear', 'tiger', 'unicorn'
];

const CATEGORIAS_PERMITIDAS = ['Funcionário', 'Aluno', 'Visitante'];

// Cadastrar novo usuário
const registerUser = async (req, res) => {
  try {
      const { nome, email, senha, categoria, turma } = req.body;

    if (!nome || !email || !senha || !categoria) {
      return res.status(400).json({ message: 'Preencha todos os campos.' });
    }

    if (!CATEGORIAS_PERMITIDAS.includes(categoria)) {
      return res.status(400).json({ message: 'Categoria inválida.' });
    }

        let turmaFinal = null;

    if (categoria === 'Aluno') {
      if (!turma) {
        return res.status(400).json({ message: 'Selecione sua turma.' });
      }
      const turmaExiste = await Turma.findOne({ nome: turma });
      if (!turmaExiste) {
        return res.status(400).json({ message: 'Turma inválida.' });
      }
      turmaFinal = turma;
    }

    const userExists = await User.findOne({ email });
    const adminExists = await Admin.findOne({ email });
    if (userExists || adminExists) {
      return res.status(400).json({ message: 'Este e-mail já está cadastrado.' });
    }

    const salt = await bcrypt.genSalt(10);
    const senhaCriptografada = await bcrypt.hash(senha, salt);

    const user = await User.create({
      nome,
      email,
      senha: senhaCriptografada,
      categoria,
      turma: turmaFinal
    });

    res.status(201).json({
      _id: user._id,
      nome: user.nome,
      email: user.email,
      role: 'user',
      categoria: user.categoria,
      avatar: user.avatar
    });

  } catch (error) {
    res.status(500).json({ message: 'Erro no servidor.', error: error.message });
  }
};

// Login — verifica na coleção "users" e, se não achar, na coleção "admins"
const loginUser = async (req, res) => {
  try {
    const { email, senha } = req.body;

    if (!email || !senha) {
      return res.status(400).json({ message: 'Preencha todos os campos.' });
    }

    let conta = await User.findOne({ email });
    let role = 'user';

    if (!conta) {
      conta = await Admin.findOne({ email });
      role = 'admin';
    }

    if (!conta) {
      return res.status(401).json({ message: 'E-mail ou senha inválidos.' });
    }

    const senhaCorreta = await bcrypt.compare(senha, conta.senha);
    if (!senhaCorreta) {
      return res.status(401).json({ message: 'E-mail ou senha inválidos.' });
    }

    if (conta.ativo === false) {
      return res.status(403).json({ message: 'Sua conta está inativa. Entre em contato com um administrador.' });
    }

    const token = jwt.sign(
      { id: conta._id, role },
      process.env.JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.status(200).json({
      _id: conta._id,
      nome: conta.nome,
      email: conta.email,
      role,
      categoria: conta.categoria || null,
      avatar: conta.avatar || null,
      token
    });

  } catch (error) {
    res.status(500).json({ message: 'Erro no servidor.', error: error.message });
  }
};

// Listar todos os usuários (comuns + admins) — somente admin pode acessar
const getUsers = async (req, res) => {
  try {
    const users = await User.find().select('-senha');
    const admins = await Admin.find().select('-senha');

    const usersComRole = users.map(u => ({ ...u.toObject(), role: 'user' }));
    const adminsComRole = admins.map(a => ({ ...a.toObject(), role: 'admin' }));

    const todos = [...usersComRole, ...adminsComRole];

    res.status(200).json(todos);
  } catch (error) {
    res.status(500).json({ message: 'Erro no servidor.', error: error.message });
  }
};

// Ativar ou desativar um usuário (comum ou admin)
const toggleUserStatus = async (req, res) => {
  try {
    const { id } = req.params;
    const { role, ativo } = req.body;

    if (req.user.id === id) {
      return res.status(400).json({ message: 'Você não pode alterar o status da sua própria conta.' });
    }

    if (typeof ativo !== 'boolean') {
      return res.status(400).json({ message: 'Valor de status inválido.' });
    }

    let conta;
    if (role === 'admin') {
      conta = await Admin.findByIdAndUpdate(id, { ativo }, { returnDocument: 'after' });
    } else {
      conta = await User.findByIdAndUpdate(id, { ativo }, { returnDocument: 'after' });
    }

    if (!conta) {
      return res.status(404).json({ message: 'Usuário não encontrado.' });
    }

    res.status(200).json({ _id: conta._id, ativo: conta.ativo });

  } catch (error) {
    res.status(500).json({ message: 'Erro no servidor.', error: error.message });
  }
};

// Atualizar o avatar do próprio usuário logado (comum ou admin)
const updateAvatar = async (req, res) => {
  try {
    const { avatar } = req.body;

    if (!avatar || !AVATARES_PERMITIDOS.includes(avatar)) {
      return res.status(400).json({ message: 'Avatar inválido.' });
    }

    let conta;
    if (req.user.role === 'admin') {
      conta = await Admin.findByIdAndUpdate(req.user.id, { avatar }, { returnDocument: 'after' });
    } else {
      conta = await User.findByIdAndUpdate(req.user.id, { avatar }, { returnDocument: 'after' });
    }

    if (!conta) {
      return res.status(404).json({ message: 'Usuário não encontrado.' });
    }

    res.status(200).json({ avatar: conta.avatar });

  } catch (error) {
    res.status(500).json({ message: 'Erro no servidor.', error: error.message });
  }
};

module.exports = { registerUser, loginUser, getUsers, toggleUserStatus, updateAvatar };