const express = require('express');
const router = express.Router();
const { getConfig, updateConfig } = require('../controllers/configController');
const { protect, isAdmin } = require('../middleware/authMiddleware');

router.get('/', protect, getConfig);
router.put('/', protect, isAdmin, updateConfig);

module.exports = router;