const express = require('express');
const router = express.Router();
const { createItem, getItems, updateItem, deleteItem, getDataServidor } = require('../controllers/itemController');
const { protect, isAdmin } = require('../middleware/authMiddleware');
const upload = require('../middleware/upload');

router.get('/data-servidor', protect, isAdmin, getDataServidor);
router.post('/', protect, isAdmin, upload.single('imagem'), createItem);
router.get('/', protect, getItems);
router.put('/:id', protect, isAdmin, upload.single('imagem'), updateItem);
router.delete('/:id', protect, isAdmin, deleteItem);

module.exports = router;