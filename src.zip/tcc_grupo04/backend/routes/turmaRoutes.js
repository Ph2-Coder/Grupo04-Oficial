const express = require('express');
const router = express.Router();
const { getTurmas, createTurma, deleteTurma } = require('../controllers/turmaController');
const { protect, isAdmin } = require('../middleware/authMiddleware');

// Pública, sem "protect": a tela de cadastro (sem login ainda) precisa listar as turmas
router.get('/', getTurmas);
router.post('/', protect, isAdmin, createTurma);
router.delete('/:id', protect, isAdmin, deleteTurma);

module.exports = router;