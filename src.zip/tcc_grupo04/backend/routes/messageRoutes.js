const express = require('express');
const router = express.Router();
const { sendMessage, reportarPerda, getMinhasMensagens, getConversas, getConversa, deleteConversa } = require('../controllers/messageController');
const { protect, isAdmin } = require('../middleware/authMiddleware');
const upload = require('../middleware/upload');

router.post('/', protect, sendMessage);
router.post('/perda', protect, upload.single('imagem'), reportarPerda);
router.get('/minhas', protect, getMinhasMensagens);
router.get('/conversas', protect, isAdmin, getConversas);
router.get('/conversa/:userId', protect, isAdmin, getConversa);
router.delete('/conversa/:userId', protect, isAdmin, deleteConversa);

module.exports = router;