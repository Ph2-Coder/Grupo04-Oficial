const express = require('express');
const router = express.Router();
const { registerUser, loginUser, getUsers, toggleUserStatus, updateAvatar } = require('../controllers/userController');
const { protect, isAdmin } = require('../middleware/authMiddleware');

router.post('/register', registerUser);
router.post('/login', loginUser);
router.get('/', protect, isAdmin, getUsers);
router.put('/avatar', protect, updateAvatar);
router.put('/:id/status', protect, isAdmin, toggleUserStatus);

module.exports = router;