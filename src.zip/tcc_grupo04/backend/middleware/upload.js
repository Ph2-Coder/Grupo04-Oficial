const multer = require('multer');

const storage = multer.memoryStorage();

const fileFilter = (req, file, cb) => {
  const tiposPermitidos = /jpeg|jpg|png|webp/;
  const extensaoValida = tiposPermitidos.test(file.originalname.toLowerCase());
  const tipoValido = tiposPermitidos.test(file.mimetype);

  if (extensaoValida && tipoValido) {
    cb(null, true);
  } else {
    cb(new Error('Apenas imagens (jpg, jpeg, png, webp) são permitidas.'));
  }
};

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB
});

module.exports = upload;