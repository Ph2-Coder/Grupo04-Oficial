import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Landing from './pages/Landing/Landing';
import Register from './pages/Register/Register';
import Login from './pages/Login/Login';
import UserDashboard from './pages/UserDashboard/UserDashboard';
import UserItens from './pages/UserItens/UserItens';
import UserMensagens from './pages/UserMensagens/UserMensagens';
import AdminDashboard from './pages/AdminDashboard/AdminDashboard';
import AdminHome from './pages/AdminHome/AdminHome';
import AdminItens from './pages/AdminItens/AdminItens';
import AdminCategorias from './pages/AdminCategorias/AdminCategorias';
import AdminTurmas from './pages/AdminTurmas/AdminTurmas';
import AdminMensagens from './pages/AdminMensagens/AdminMensagens';
import AdminLayout from './layouts/AdminLayout';
import UserLayout from './layouts/UserLayout';
import PrivateRoute from './components/PrivateRoute';
import AdminRoute from './components/AdminRoute';
import EmDesenvolvimento from './components/EmDesenvolvimento/EmDesenvolvimento';
import './App.css';

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />

        <Route
          path="/home"
          element={
            <PrivateRoute>
              <UserLayout />
            </PrivateRoute>
          }
        >
          <Route index element={<UserDashboard />} />
          <Route path="itens" element={<UserItens />} />
          <Route path="busca" element={<EmDesenvolvimento titulo="Busca" />} />
          <Route path="mensagens" element={<UserMensagens />} />
        </Route>

        <Route
          path="/admin"
          element={
            <AdminRoute>
              <AdminLayout />
            </AdminRoute>
          }
        >
          <Route index element={<AdminDashboard />} />
          <Route path="itens" element={<AdminItens />} />
          <Route path="categorias" element={<AdminCategorias />} />
          <Route path="turmas" element={<AdminTurmas />} />
          <Route path="busca" element={<EmDesenvolvimento titulo="Busca" />} />
          <Route path="mensagens" element={<AdminMensagens />} />
          <Route path="alunos" element={<EmDesenvolvimento titulo="Alunos" />} />
          <Route path="usuarios" element={<AdminHome />} />
        </Route>

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;