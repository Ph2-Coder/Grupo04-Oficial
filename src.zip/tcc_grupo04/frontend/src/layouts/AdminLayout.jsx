import { Outlet } from 'react-router-dom';
import { Package, Tag, MessageCircle, GraduationCap, Users, Home } from 'lucide-react';
import Sidebar from '../components/Sidebar/Sidebar';
import EventoBannerAdmin from '../components/EventoBannerAdmin/EventoBannerAdmin';
import './AdminLayout.css';

const menuItemsAdmin = [
  { path: '/admin', label: 'Painel', icon: Home, end: true },
  { path: '/admin/itens', label: 'Itens', icon: Package },
  { path: '/admin/categorias', label: 'Categorias', icon: Tag },
  { path: '/admin/turmas', label: 'Turmas', icon: GraduationCap },
  { path: '/admin/mensagens', label: 'Mensagens', icon: MessageCircle },
  { path: '/admin/usuarios', label: 'Usuários', icon: Users }
];

function AdminLayout() {
  return (
    <div className="admin-layout">
      <Sidebar menuItems={menuItemsAdmin} />
      <div className="admin-layout-content">
        <EventoBannerAdmin />
        <Outlet />
      </div>
    </div>
  );
}

export default AdminLayout;