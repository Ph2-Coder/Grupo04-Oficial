import { Outlet } from 'react-router-dom';
import { Package, MessageCircle, Home } from 'lucide-react';
import Sidebar from '../components/Sidebar/Sidebar';
import './AdminLayout.css';

const menuItemsUser = [
  { path: '/home', label: 'Painel', icon: Home, end: true },
  { path: '/home/itens', label: 'Itens', icon: Package },
  { path: '/home/mensagens', label: 'Mensagens', icon: MessageCircle }
];

function UserLayout() {
  return (
    <div className="admin-layout">
      <Sidebar menuItems={menuItemsUser} />
      <div className="admin-layout-content">
        <Outlet />
      </div>
    </div>
  );
}

export default UserLayout;