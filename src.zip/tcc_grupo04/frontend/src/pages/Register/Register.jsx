import { useState, useEffect } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import AnimatedBackground from '../../components/AnimatedBackground/AnimatedBackground';
import ThemeToggle from '../../components/ThemeToggle/ThemeToggle';
import './Register.css';

function Register() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    nome: '',
    email: '',
    senha: '',
    confirmarSenha: '',
    categoria: '',
    turma: ''
  });
  const [erro, setErro] = useState('');
  const [carregando, setCarregando] = useState(false);
  const [mostrarSenha, setMostrarSenha] = useState(false);
  const [mostrarConfirmarSenha, setMostrarConfirmarSenha] = useState(false);
  const [turmas, setTurmas] = useState([]);
  const [carregandoTurmas, setCarregandoTurmas] = useState(false);

  useEffect(() => {
    if (formData.categoria === 'Aluno' && turmas.length === 0) {
      buscarTurmas();
    }
  }, [formData.categoria]);

  const buscarTurmas = async () => {
    setCarregandoTurmas(true);
    try {
      const response = await axios.get('http://localhost:5000/api/turmas');
      setTurmas(response.data);
    } catch (err) {
      console.error('Erro ao buscar turmas:', err);
    } finally {
      setCarregandoTurmas(false);
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleCategoriaChange = (e) => {
    setFormData({ ...formData, categoria: e.target.value, turma: '' });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErro('');

    if (formData.senha !== formData.confirmarSenha) {
      setErro('As senhas não coincidem.');
      return;
    }

    if (!formData.categoria) {
      setErro('Selecione sua categoria.');
      return;
    }

    if (formData.categoria === 'Aluno' && !formData.turma) {
      setErro('Selecione sua turma.');
      return;
    }

    setCarregando(true);
    try {
      await axios.post('http://localhost:5000/api/users/register', {
        nome: formData.nome,
        email: formData.email,
        senha: formData.senha,
        categoria: formData.categoria,
        turma: formData.categoria === 'Aluno' ? formData.turma : undefined
      });

      alert('Conta criada com sucesso! Faça login para continuar.');
      navigate('/login');

    } catch (err) {
      setErro(err.response?.data?.message || 'Erro ao criar conta.');
    } finally {
      setCarregando(false);
    }
  };

  return (
    <>
      <AnimatedBackground />
      <ThemeToggle variante="flutuante" />
      <div className="register-container">
        <div className="register-header">
          <h1>Crie sua conta</h1>
          <p>Cadastre-se para começar</p>
        </div>

        <div className="register-card">
          <form onSubmit={handleSubmit}>
            <label htmlFor="nome">Nome</label>
            <input
              type="text"
              id="nome"
              name="nome"
              placeholder="Seu nome completo"
              value={formData.nome}
              onChange={handleChange}
              required
            />

            <label htmlFor="email">E-mail</label>
            <input
              type="email"
              id="email"
              name="email"
              placeholder="voce@exemplo.com"
              value={formData.email}
              onChange={handleChange}
              required
            />

            <label htmlFor="categoria">Você é</label>
            <select
              id="categoria"
              name="categoria"
              value={formData.categoria}
              onChange={handleCategoriaChange}
              required
            >
              <option value="" disabled>Selecione uma opção</option>
              <option value="Funcionário">Funcionário</option>
              <option value="Aluno">Aluno</option>
              <option value="Visitante">Visitante</option>
            </select>

            {formData.categoria === 'Aluno' && (
              <>
                <label htmlFor="turma">Turma</label>
                <select
                  id="turma"
                  name="turma"
                  value={formData.turma}
                  onChange={handleChange}
                  required
                >
                  <option value="" disabled>
                    {carregandoTurmas ? 'Carregando turmas...' : 'Selecione sua turma'}
                  </option>
                  {turmas.map((t) => (
                    <option key={t._id} value={t.nome}>{t.nome}</option>
                  ))}
                </select>
                {!carregandoTurmas && turmas.length === 0 && (
                  <p className="campo-aviso">Nenhuma turma cadastrada ainda. Fale com um responsável dos achados e perdidos.</p>
                )}
              </>
            )}

            <label htmlFor="senha">Senha</label>
            <div className="senha-wrapper">
              <input
                type={mostrarSenha ? 'text' : 'password'}
                id="senha"
                name="senha"
                placeholder="••••••••"
                value={formData.senha}
                onChange={handleChange}
                required
                minLength={6}
              />
              <button
                type="button"
                className="btn-olho-senha"
                onClick={() => setMostrarSenha(!mostrarSenha)}
                tabIndex={-1}
                title={mostrarSenha ? 'Ocultar senha' : 'Mostrar senha'}
              >
                {mostrarSenha ? '🔒' : '👁'}
              </button>
            </div>

            <label htmlFor="confirmarSenha">Confirmar Senha</label>
            <div className="senha-wrapper">
              <input
                type={mostrarConfirmarSenha ? 'text' : 'password'}
                id="confirmarSenha"
                name="confirmarSenha"
                placeholder="••••••••"
                value={formData.confirmarSenha}
                onChange={handleChange}
                required
                minLength={6}
              />
              <button
                type="button"
                className="btn-olho-senha"
                onClick={() => setMostrarConfirmarSenha(!mostrarConfirmarSenha)}
                tabIndex={-1}
                title={mostrarConfirmarSenha ? 'Ocultar senha' : 'Mostrar senha'}
              >
                {mostrarConfirmarSenha ? '🔒' : '👁'}
              </button>
            </div>

            {erro && <p className="erro-msg">{erro}</p>}

            <button type="submit" className="submit-btn" disabled={carregando}>
              {carregando ? 'Criando...' : 'Criar conta'}
            </button>
          </form>

          <p className="login-link">
            Já tem uma conta? <Link to="/login">Entrar</Link>
          </p>
        </div>
      </div>
    </>
  );
}

export default Register;