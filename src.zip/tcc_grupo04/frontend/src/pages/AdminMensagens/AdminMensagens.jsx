import { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { ArrowLeft } from 'lucide-react';
import './AdminMensagens.css';
import NovaConversaModal from '../../components/NovaConversaModal/NovaConversaModal';
import ConfirmModal from '../../components/ConfirmModal/ConfirmModal';
import { getAvatarInfo } from '../../components/AvatarPickerModal/AvatarPickerModal';

function AdminMensagens() {
  const [conversas, setConversas] = useState([]);
  const [conversaAtiva, setConversaAtiva] = useState(null);
  const [mensagens, setMensagens] = useState([]);
  const [texto, setTexto] = useState('');
  const [carregandoConversas, setCarregandoConversas] = useState(true);
  const [carregandoMensagens, setCarregandoMensagens] = useState(false);
  const [enviando, setEnviando] = useState(false);
  const fimRef = useRef(null);
  const [modalNovaConversa, setModalNovaConversa] = useState(false);
  const [conversaParaExcluir, setConversaParaExcluir] = useState(null);

  useEffect(() => {
    buscarConversas();
    const intervalo = setInterval(buscarConversas, 5000);
    return () => clearInterval(intervalo);
  }, []);

  useEffect(() => {
    if (conversaAtiva) {
      buscarMensagens(conversaAtiva.userId, true);
      const intervalo = setInterval(() => buscarMensagens(conversaAtiva.userId, false), 4000);
      return () => clearInterval(intervalo);
    }
  }, [conversaAtiva]);

  useEffect(() => {
    fimRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [mensagens]);

  const buscarConversas = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:5000/api/messages/conversas', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setConversas(response.data);
    } catch (err) {
      console.error('Erro ao buscar conversas:', err);
    } finally {
      setCarregandoConversas(false);
    }
  };

  const buscarMensagens = async (userId, mostrarCarregando = false) => {
    if (mostrarCarregando) setCarregandoMensagens(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get(`http://localhost:5000/api/messages/conversa/${userId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setMensagens(response.data);
    } catch (err) {
      console.error('Erro ao buscar mensagens:', err);
    } finally {
      if (mostrarCarregando) setCarregandoMensagens(false);
    }
  };

  const enviarMensagem = async (e) => {
    e.preventDefault();
    if (!texto.trim() || !conversaAtiva) return;

    setEnviando(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(
        'http://localhost:5000/api/messages',
        { conteudo: texto, userId: conversaAtiva.userId },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setMensagens([...mensagens, response.data]);
      setTexto('');
    } catch (err) {
      alert(err.response?.data?.message || 'Erro ao enviar mensagem.');
    } finally {
      setEnviando(false);
    }
  };

  const formatarHora = (dataISO) => {
    return new Date(dataISO).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  };

  const formatarSeparadorData = (dataISO) => {
    const data = new Date(dataISO);
    const hoje = new Date();
    const ontem = new Date();
    ontem.setDate(hoje.getDate() - 1);

    const mesmoDia = (a, b) =>
      a.getDate() === b.getDate() &&
      a.getMonth() === b.getMonth() &&
      a.getFullYear() === b.getFullYear();

    if (mesmoDia(data, hoje)) return 'Hoje';
    if (mesmoDia(data, ontem)) return 'Ontem';

    return data.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    });
  };

  const mesmoDiaISO = (dataA, dataB) => {
    const a = new Date(dataA);
    const b = new Date(dataB);
    return (
      a.getDate() === b.getDate() &&
      a.getMonth() === b.getMonth() &&
      a.getFullYear() === b.getFullYear()
    );
  };

  const iniciarConversa = (usuario) => {
    const jaExiste = conversas.find((c) => c.userId === usuario.userId);

    if (jaExiste) {
      setConversaAtiva(jaExiste);
    } else {
      setConversaAtiva({ ...usuario, ultimaMensagem: '', naoLidas: 0 });
      setMensagens([]);
    }

    setModalNovaConversa(false);
  };

  // Celular: volta da conversa para a lista
  const voltarParaLista = () => {
    setConversaAtiva(null);
    setMensagens([]);
  };

  const confirmarExclusaoConversa = async () => {
    if (!conversaParaExcluir) return;

    try {
      const token = localStorage.getItem('token');
      await axios.delete(`http://localhost:5000/api/messages/conversa/${conversaParaExcluir.userId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });

      setConversas(conversas.filter((c) => c.userId !== conversaParaExcluir.userId));

      if (conversaAtiva?.userId === conversaParaExcluir.userId) {
        setConversaAtiva(null);
        setMensagens([]);
      }
    } catch (err) {
      alert(err.response?.data?.message || 'Erro ao excluir conversa.');
    } finally {
      setConversaParaExcluir(null);
    }
  };

  return (
    <div className="chat-container">
      <div className="chat-header">
        <h1>Mensagens</h1>
        <p>Converse com os usuários do sistema</p>
      </div>

      <div className="chat-layout">
        <div className="chat-lista">
          <button className="btn-nova-conversa" onClick={() => setModalNovaConversa(true)}>
            + Nova Conversa
          </button>
          {carregandoConversas && <p className="status-msg">Carregando...</p>}
          {!carregandoConversas && conversas.length === 0 && (
            <p className="status-msg">Nenhuma conversa ainda.</p>
          )}
          {conversas.map((c) => {
            const avatarInfo = getAvatarInfo(c.avatar);
            return (
              <div
                key={c.userId}
                className={`chat-conversa-item ${conversaAtiva?.userId === c.userId ? 'ativa' : ''}`}
              >
                <button
                  className="chat-conversa-clicavel"
                  onClick={() => setConversaAtiva(c)}
                >
                  <div
                    className="chat-conversa-avatar"
                    style={avatarInfo ? { backgroundColor: avatarInfo.cor } : undefined}
                  >
                    {avatarInfo ? avatarInfo.emoji : c.nome?.charAt(0).toUpperCase()}
                  </div>
                  <div className="chat-conversa-info">
                    <strong>{c.nome}</strong>
                    <span>{c.ultimaMensagem}</span>
                  </div>
                  {c.naoLidas > 0 && <span className="chat-badge">{c.naoLidas}</span>}
                </button>
                <button
                  className="chat-conversa-excluir"
                  onClick={() => setConversaParaExcluir(c)}
                  title="Excluir conversa"
                >
                  🗑
                </button>
              </div>
            );
          })}
        </div>

        <div className="chat-box">
          {!conversaAtiva && (
            <div className="chat-vazio chat-vazio-central">
              <span>💬</span>
              <p>Selecione uma conversa para começar</p>
            </div>
          )}

          {conversaAtiva && (
            <>
              <div className="chat-box-header">
                <button
                  type="button"
                  className="chat-voltar"
                  onClick={voltarParaLista}
                  aria-label="Voltar para a lista de conversas"
                >
                  <ArrowLeft size={22} strokeWidth={2} />
                </button>
                <strong>{conversaAtiva.nome}</strong>
                <span>{conversaAtiva.email}</span>
              </div>

              <div className="chat-messages">
                {carregandoMensagens && <p className="status-msg">Carregando mensagens...</p>}
                {mensagens.map((msg, index) => {
                  const mensagemAnterior = mensagens[index - 1];
                  const mostrarSeparador =
                    !mensagemAnterior || !mesmoDiaISO(mensagemAnterior.createdAt, msg.createdAt);

                  return (
                    <div key={msg._id}>
                      {mostrarSeparador && (
                        <div className="chat-date-separator">
                          <span>{formatarSeparadorData(msg.createdAt)}</span>
                        </div>
                      )}

                      {msg.tipo === 'perda' ? (
                        <div className="chat-bubble-wrapper align-left">
                          <div className="chat-relato-card">
                            <span className="chat-relato-titulo">📋 Item perdido relatado</span>
                            {msg.itemPerdido?.imagem?.data && (
                              <img
                                className="chat-relato-imagem"
                                src={`data:${msg.itemPerdido.imagem.contentType};base64,${msg.itemPerdido.imagem.data}`}
                                alt={msg.itemPerdido.nome}
                              />
                            )}
                            <strong>{msg.itemPerdido?.nome}</strong>
                            {msg.itemPerdido?.descricao && <p>{msg.itemPerdido.descricao}</p>}
                            {msg.itemPerdido?.local && (
                              <span className="chat-relato-local">📍 {msg.itemPerdido.local}</span>
                            )}
                            <span className="chat-bubble-hora">{formatarHora(msg.createdAt)}</span>
                          </div>
                        </div>
                      ) : (
                        <div
                          className={`chat-bubble-wrapper ${msg.remetenteRole === 'admin' ? 'align-right' : 'align-left'}`}
                        >
                          <div className={`chat-bubble ${msg.remetenteRole === 'admin' ? 'bubble-user' : 'bubble-admin'}`}>
                            {msg.remetenteRole === 'user' && (
                              <span className="chat-bubble-autor">{msg.remetenteNome}</span>
                            )}
                            <p>{msg.conteudo}</p>
                            <span className="chat-bubble-hora">{formatarHora(msg.createdAt)}</span>
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
                <div ref={fimRef} />
              </div>

              <form className="chat-input-bar" onSubmit={enviarMensagem}>
                <input
                  type="text"
                  placeholder="Digite sua mensagem..."
                  value={texto}
                  onChange={(e) => setTexto(e.target.value)}
                />
                <button type="submit" disabled={enviando || !texto.trim()}>
                  Enviar
                </button>
              </form>
            </>
          )}
        </div>
      </div>

      {modalNovaConversa && (
        <NovaConversaModal
          onClose={() => setModalNovaConversa(false)}
          onSelecionar={iniciarConversa}
        />
      )}

      {conversaParaExcluir && (
        <ConfirmModal
          titulo="Excluir conversa"
          mensagem={`Tem certeza que deseja excluir toda a conversa com "${conversaParaExcluir.nome}"? Essa ação não pode ser desfeita.`}
          textoConfirmar="Excluir"
          perigo={true}
          onConfirmar={confirmarExclusaoConversa}
          onCancelar={() => setConversaParaExcluir(null)}
        />
      )}
    </div>
  );
}

export default AdminMensagens;