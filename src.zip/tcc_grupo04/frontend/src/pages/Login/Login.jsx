import { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import axios from 'axios';
import AnimatedBackground from '../../components/AnimatedBackground/AnimatedBackground';
import ThemeToggle from '../../components/ThemeToggle/ThemeToggle';
import './Login.css';

function Login() {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    email: '',
    senha: ''
  });
  const [erro, setErro] = useState('');
  const [carregando, setCarregando] = useState(false);
  const [mostrarSenha, setMostrarSenha] = useState(false);

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErro('');
    setCarregando(true);

    try {
      const response = await axios.post('http://localhost:5000/api/users/login', {
        email: formData.email,
        senha: formData.senha
      });

      localStorage.setItem('token', response.data.token);
      localStorage.setItem('usuario', JSON.stringify({
        nome: response.data.nome,
        email: response.data.email,
        role: response.data.role,
        categoria: response.data.categoria,
        avatar: response.data.avatar
      }));

      if (response.data.role === 'admin') {
        navigate('/admin');
      } else {
        navigate('/home');
      }

    } catch (err) {
      setErro(err.response?.data?.message || 'Erro ao fazer login.');
    } finally {
      setCarregando(false);
    }
  };

  return (
    <>
      <AnimatedBackground />
      <ThemeToggle variante="flutuante" />
      <div className="login-container">
        <div className="login-header">
          <h1>Entrar</h1>
          <p>Acesse sua conta para continuar</p>
        </div>

        <div className="login-card">
          <form onSubmit={handleSubmit}>
            <label htmlFor="email">E-mail</label>
            <input
              type="email"
              id="email"
              name="email"
              placeholder="voce@exemplo.com"
              value={formData.email}
              onChange={handleChange}
              required
            />

            <label htmlFor="senha">Senha</label>
            <div className="senha-wrapper">
              <input
                type={mostrarSenha ? 'text' : 'password'}
                id="senha"
                name="senha"
                placeholder="••••••••"
                value={formData.senha}
                onChange={handleChange}
                required
              />
              <button
                type="button"
                className="btn-olho-senha"
                onClick={() => setMostrarSenha(!mostrarSenha)}
                tabIndex={-1}
                title={mostrarSenha ? 'Ocultar senha' : 'Mostrar senha'}
              >
                {mostrarSenha ? '🔒' : '👁'}
              </button>
            </div>

            {erro && <p className="erro-msg">{erro}</p>}

            <button type="submit" className="submit-btn" disabled={carregando}>
              {carregando ? 'Entrando...' : 'Entrar'}
            </button>
          </form>

          <p className="login-link">
            Não tem uma conta? <Link to="/register">Cadastre-se</Link>
          </p>
        </div>
      </div>
    </>
  );
}

export default Login;