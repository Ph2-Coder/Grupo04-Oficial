import { useState, useEffect } from 'react';
import axios from 'axios';
import ItemDetailModal from '../../components/ItemDetailModal/ItemDetailModal';
import { useEvento } from '../../hooks/useEvento';
import '../AdminItens/AdminItens.css';

function UserItens() {
  const { eventoAtivo, carregado } = useEvento();
  const [items, setItems] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState('');
  const [busca, setBusca] = useState('');
  const [filtroStatus, setFiltroStatus] = useState('Todos');
  const [itemSelecionado, setItemSelecionado] = useState(null);

  // Busca os itens quando o modo evento é conhecido e sempre que ele muda.
  // Quem decide o que vem na lista é o servidor.
  useEffect(() => {
    if (!carregado) return;

    buscarItens();
    if (!eventoAtivo) setFiltroStatus('Todos');
  }, [carregado, eventoAtivo]);

  const buscarItens = async () => {
    setCarregando(true);
    setErro('');
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:5000/api/items', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setItems(response.data);
    } catch (err) {
      setErro(err.response?.data?.message || 'Erro ao buscar itens.');
    } finally {
      setCarregando(false);
    }
  };

  const itensFiltrados = items.filter((item) => {
    const textoBusca = busca.toLowerCase();
    const bateBusca =
      item.nome.toLowerCase().includes(textoBusca) ||
      item.descricao?.toLowerCase().includes(textoBusca) ||
      item.categoria?.toLowerCase().includes(textoBusca) ||
      item.local?.toLowerCase().includes(textoBusca);

    const bateStatus =
      !eventoAtivo || filtroStatus === 'Todos' || item.status === filtroStatus;

    return bateBusca && bateStatus;
  });

  const mensagemVazio =
    items.length === 0
      ? eventoAtivo
        ? 'Nenhum item registrado ainda.'
        : 'Nenhum item foi devolvido ainda.'
      : 'Nenhum item encontrado com esse filtro.';

  return (
    <div>
      <div className="itens-header">
        <h1>{eventoAtivo ? 'Itens' : 'Itens Devolvidos'}</h1>
      </div>

      <div className="itens-filtros">
        <input
          type="text"
          className="itens-busca"
          placeholder="🔍 Buscar por nome, categoria, local..."
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
        />

        {eventoAtivo && (
          <select
            className="itens-filtro-status"
            value={filtroStatus}
            onChange={(e) => setFiltroStatus(e.target.value)}
            aria-label="Filtrar por status"
          >
            <option value="Todos">Todos os status</option>
            <option value="Pendente">Pendente</option>
            <option value="Devolvido">Devolvido</option>
          </select>
        )}
      </div>

      {carregando && <p className="status-msg">Carregando itens...</p>}
      {erro && <p className="erro-msg">{erro}</p>}

      {!carregando && !erro && itensFiltrados.length === 0 && (
        <div className="itens-vazio">
          <span>📦</span>
          <p>{mensagemVazio}</p>
        </div>
      )}

      <div className="itens-grid">
        {itensFiltrados.map((item) => (
          <div className="item-card" key={item._id} onClick={() => setItemSelecionado(item)}>
            <div className="item-card-imagem">
              {item.imagem?.data ? (
                <img
                  src={`data:${item.imagem.contentType};base64,${item.imagem.data}`}
                  alt={item.nome}
                />
              ) : (
                <span className="item-sem-imagem">📦</span>
              )}
            </div>
            <div className="item-card-info">
              <div className="item-card-top">
                <h3>{item.nome}</h3>
                <span
                  className={`status-badge ${
                    item.status === 'Devolvido' ? 'status-devolvido' : 'status-pendente'
                  }`}
                >
                  {item.status}
                </span>
              </div>
              <p className="item-card-desc">{item.descricao || 'Sem descrição.'}</p>
              <div className="item-card-tags">
                <span className="tag">{item.tipo}</span>
                <span className="tag">{item.categoria}</span>
                {item.local && <span className="tag">{item.local}</span>}
              </div>
            </div>
          </div>
        ))}
      </div>

      {itemSelecionado && (
        <ItemDetailModal
          item={itemSelecionado}
          onClose={() => setItemSelecionado(null)}
        />
      )}
    </div>
  );
}

export default UserItens;