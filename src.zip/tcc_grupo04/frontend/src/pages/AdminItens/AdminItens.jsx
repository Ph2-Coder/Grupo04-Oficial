import { useState, useEffect } from 'react';
import axios from 'axios';
import ItemModal from '../../components/ItemModal/ItemModal';
import ConfirmModal from '../../components/ConfirmModal/ConfirmModal';
import ItemDetailModal from '../../components/ItemDetailModal/ItemDetailModal';
import './AdminItens.css';

function AdminItens() {
  const [items, setItems] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState('');
  const [modalAberto, setModalAberto] = useState(false);
  const [itemEditando, setItemEditando] = useState(null);
  const [busca, setBusca] = useState('');
  const [filtroStatus, setFiltroStatus] = useState('Todos');
  const [itemParaExcluir, setItemParaExcluir] = useState(null);
  const [itemSelecionado, setItemSelecionado] = useState(null);

  useEffect(() => {
    buscarItens();
  }, []);

  const buscarItens = async () => {
    setCarregando(true);
    setErro('');
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:5000/api/items', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setItems(response.data);
    } catch (err) {
      setErro(err.response?.data?.message || 'Erro ao buscar itens.');
    } finally {
      setCarregando(false);
    }
  };

  const handleItemSalvo = (itemSalvo) => {
    const jaExiste = items.some((i) => i._id === itemSalvo._id);
    if (jaExiste) {
      setItems(items.map((i) => (i._id === itemSalvo._id ? itemSalvo : i)));
    } else {
      setItems([itemSalvo, ...items]);
    }
    setItemEditando(null);
  };

  const confirmarExclusao = async () => {
  if (!itemParaExcluir) return;

  try {
    const token = localStorage.getItem('token');
    await axios.delete(`http://localhost:5000/api/items/${itemParaExcluir._id}`, {
      headers: { Authorization: `Bearer ${token}` }
    });
    setItems(items.filter((i) => i._id !== itemParaExcluir._id));
  } catch (err) {
    alert(err.response?.data?.message || 'Erro ao excluir item.');
  } finally {
    setItemParaExcluir(null);
  }
};

  const abrirEdicao = (item) => {
    setItemEditando(item);
    setModalAberto(true);
  };

  const abrirCriacao = () => {
    setItemEditando(null);
    setModalAberto(true);
  };

  // Filtra os itens pelo texto buscado e pelo status selecionado
  const itensFiltrados = items.filter((item) => {
    const textoBusca = busca.toLowerCase();
    const bateBusca =
      item.nome.toLowerCase().includes(textoBusca) ||
      item.descricao?.toLowerCase().includes(textoBusca) ||
      item.categoria?.toLowerCase().includes(textoBusca) ||
      item.local?.toLowerCase().includes(textoBusca);

    const bateStatus = filtroStatus === 'Todos' || item.status === filtroStatus;

    return bateBusca && bateStatus;
  });

  return (
    <div>
      <div className="itens-header">
        <h1>Itens</h1>
        <button className="btn-primary" onClick={abrirCriacao}>
          + Registrar Item
        </button>
      </div>

      <div className="itens-filtros">
        <input
          type="text"
          className="itens-busca"
          placeholder="🔍 Buscar por nome, categoria, local..."
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
        />
        <select
          className="itens-filtro-status"
          value={filtroStatus}
          onChange={(e) => setFiltroStatus(e.target.value)}
        >
          <option value="Todos">Todos os status</option>
          <option value="Pendente">Pendente</option>
          <option value="Devolvido">Devolvido</option>
        </select>
      </div>

      {carregando && <p className="status-msg">Carregando itens...</p>}
      {erro && <p className="erro-msg">{erro}</p>}

      {!carregando && !erro && itensFiltrados.length === 0 && (
        <div className="itens-vazio">
          <span>📦</span>
          <p>{items.length === 0 ? 'Nenhum item registrado ainda.' : 'Nenhum item encontrado com esse filtro.'}</p>
        </div>
      )}

      <div className="itens-grid">
        {itensFiltrados.map((item) => (
          <div className="item-card" key={item._id} onClick={() => setItemSelecionado(item)}>
            <div className="item-card-imagem">
              {item.imagem?.data ? (
                <img
                  src={`data:${item.imagem.contentType};base64,${item.imagem.data}`}
                  alt={item.nome}
                />
              ) : (
                <span className="item-sem-imagem">📦</span>
              )}
            </div>
            <div className="item-card-info">
              <div className="item-card-top">
                <h3>{item.nome}</h3>
                <span className={`status-badge ${item.status === 'Devolvido' ? 'status-devolvido' : 'status-pendente'}`}>
                  {item.status}
                </span>
              </div>
              <p className="item-card-desc">{item.descricao || 'Sem descrição.'}</p>
              <div className="item-card-tags">
                <span className="tag">{item.tipo}</span>
                <span className="tag">{item.categoria}</span>
                {item.local && <span className="tag">{item.local}</span>}
              </div>
              <div className="item-card-actions">
              <button className="btn-editar" onClick={(e) => { e.stopPropagation(); abrirEdicao(item); }}>
                ✎ Editar
              </button>
              <button className="btn-excluir" onClick={(e) => { e.stopPropagation(); setItemParaExcluir(item); }}>
                🗑 Excluir
              </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {modalAberto && (
        <ItemModal
          onClose={() => { setModalAberto(false); setItemEditando(null); }}
          onItemSalvo={handleItemSalvo}
          itemParaEditar={itemEditando}
        />
      )}
      {itemParaExcluir && (
  <ConfirmModal
    titulo="Excluir item"
    mensagem={`Tem certeza que deseja excluir "${itemParaExcluir.nome}"? Essa ação não pode ser desfeita.`}
    textoConfirmar="Excluir"
    perigo={true}
    onConfirmar={confirmarExclusao}
    onCancelar={() => setItemParaExcluir(null)}
  />
)}

{itemSelecionado && (
  <ItemDetailModal
    item={itemSelecionado}
    onClose={() => setItemSelecionado(null)}
  />
  )}
    </div>
  );
}

export default AdminItens;