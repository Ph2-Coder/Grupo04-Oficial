import { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import '../AdminMensagens/AdminMensagens.css';

function UserMensagens() {
  const [mensagens, setMensagens] = useState([]);
  const [texto, setTexto] = useState('');
  const [carregando, setCarregando] = useState(true);
  const [enviando, setEnviando] = useState(false);
  const fimRef = useRef(null);

  // Formulário de relato de item perdido
  const [formNome, setFormNome] = useState('');
  const [formDescricao, setFormDescricao] = useState('');
  const [formLocal, setFormLocal] = useState('');
  const [formImagem, setFormImagem] = useState(null);
  const [formPreview, setFormPreview] = useState(null);
  const [enviandoForm, setEnviandoForm] = useState(false);
  const [erroForm, setErroForm] = useState('');

  // Regras de acesso ao chat
  const adminIniciou = mensagens.some((m) => m.remetenteRole === 'admin');
  const jaRelatouPerda = mensagens.some((m) => m.tipo === 'perda');
  const adminRespondeuAposRelato = mensagens.some((m) => m.remetenteRole === 'admin');

  // O chat está liberado se:
  // 1. O admin mandou uma mensagem primeiro (independente de formulário)
  // 2. OU o usuário já relatou a perda E o admin já respondeu
  const chatLiberado = adminIniciou || (jaRelatouPerda && adminRespondeuAposRelato);

  // Mostra aviso de "aguardando" quando: usuário relatou mas admin ainda não respondeu
  const aguardandoResposta = jaRelatouPerda && !adminRespondeuAposRelato && !adminIniciou;

  // Mostra o formulário quando: não há nenhuma mensagem do admin E o usuário ainda não relatou
  const mostrarFormulario = !adminIniciou && !jaRelatouPerda;

  useEffect(() => {
    buscarMensagens(true);
    const intervalo = setInterval(() => buscarMensagens(false), 4000);
    return () => clearInterval(intervalo);
  }, []);

  useEffect(() => {
    fimRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [mensagens]);

  const buscarMensagens = async (mostrarCarregando = false) => {
    if (mostrarCarregando) setCarregando(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:5000/api/messages/minhas', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setMensagens(response.data);
    } catch (err) {
      console.error('Erro ao buscar mensagens:', err);
    } finally {
      setCarregando(false);
    }
  };

  const handleImagemChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormImagem(file);
      setFormPreview(URL.createObjectURL(file));
    }
  };

  const enviarRelato = async (e) => {
    e.preventDefault();
    setErroForm('');

    if (!formNome.trim()) {
      setErroForm('Informe o nome do item que você perdeu.');
      return;
    }

    setEnviandoForm(true);
    try {
      const token = localStorage.getItem('token');
      const dataToSend = new FormData();
      dataToSend.append('nome', formNome);
      dataToSend.append('descricao', formDescricao);
      dataToSend.append('local', formLocal);
      if (formImagem) {
        dataToSend.append('imagem', formImagem);
      }

      const response = await axios.post(
        'http://localhost:5000/api/messages/perda',
        dataToSend,
        { headers: { Authorization: `Bearer ${token}` } }
      );

      setMensagens([...mensagens, response.data]);
    } catch (err) {
      setErroForm(err.response?.data?.message || 'Erro ao enviar relato.');
    } finally {
      setEnviandoForm(false);
    }
  };

  const enviarMensagem = async (e) => {
    e.preventDefault();
    if (!texto.trim()) return;

    setEnviando(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(
        'http://localhost:5000/api/messages',
        { conteudo: texto },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setMensagens([...mensagens, response.data]);
      setTexto('');
    } catch (err) {
      alert(err.response?.data?.message || 'Erro ao enviar mensagem.');
    } finally {
      setEnviando(false);
    }
  };

  const formatarHora = (dataISO) => {
    return new Date(dataISO).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
  };

  const formatarSeparadorData = (dataISO) => {
    const data = new Date(dataISO);
    const hoje = new Date();
    const ontem = new Date();
    ontem.setDate(hoje.getDate() - 1);

    const mesmoDia = (a, b) =>
      a.getDate() === b.getDate() &&
      a.getMonth() === b.getMonth() &&
      a.getFullYear() === b.getFullYear();

    if (mesmoDia(data, hoje)) return 'Hoje';
    if (mesmoDia(data, ontem)) return 'Ontem';

    return data.toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: 'long',
      year: 'numeric'
    });
  };

  const mesmoDiaISO = (dataA, dataB) => {
    const a = new Date(dataA);
    const b = new Date(dataB);
    return (
      a.getDate() === b.getDate() &&
      a.getMonth() === b.getMonth() &&
      a.getFullYear() === b.getFullYear()
    );
  };

  if (carregando) {
    return (
      <div className="chat-container chat-single">
        <div className="chat-header">
          <h1>Mensagens</h1>
          <p>Converse com o responsável dos achados e perdidos</p>
        </div>
        <div className="chat-box">
          <p className="status-msg">Carregando...</p>
        </div>
      </div>
    );
  }

  // Mostra o formulário quando o usuário ainda não relatou nada
  // e o admin também ainda não entrou em contato
  if (mostrarFormulario) {
    return (
      <div className="chat-container chat-single">
        <div className="chat-header">
          <h1>Mensagens</h1>
          <p>Antes de conversar, conte pra gente o que você perdeu</p>
        </div>

        <div className="chat-box">
          <form className="relato-form" onSubmit={enviarRelato}>
            <label>Nome do item</label>
            <input
              type="text"
              placeholder="ex. Estojo azul, celular, carteira..."
              value={formNome}
              onChange={(e) => setFormNome(e.target.value)}
              required
            />

            <label>Descrição</label>
            <textarea
              rows="3"
              placeholder="Descreva detalhes que ajudem a identificar o item"
              value={formDescricao}
              onChange={(e) => setFormDescricao(e.target.value)}
            />

            <label>Onde você acha que perdeu</label>
            <input
              type="text"
              placeholder="ex. Biblioteca, quadra, sala 12..."
              value={formLocal}
              onChange={(e) => setFormLocal(e.target.value)}
            />

            <label>Imagem (opcional)</label>
            <label className="upload-box">
              {formPreview ? (
                <img src={formPreview} alt="Preview" className="upload-preview" />
              ) : (
                <>
                  <span className="upload-icon">⬆</span>
                  <span>Clique para enviar uma imagem parecida</span>
                </>
              )}
              <input
                type="file"
                accept="image/*"
                onChange={handleImagemChange}
                hidden
              />
            </label>

            {erroForm && <p className="modal-erro">{erroForm}</p>}

            <button type="submit" className="btn-primary relato-submit" disabled={enviandoForm}>
              {enviandoForm ? 'Enviando...' : 'Enviar relato e iniciar conversa'}
            </button>
          </form>
        </div>
      </div>
    );
  }

  // Chat normal — com mensagens visíveis e input liberado ou bloqueado conforme as regras
  return (
    <div className="chat-container chat-single">
      <div className="chat-header">
        <h1>Mensagens</h1>
        <p>Converse com os reponsáveis dos achados e perdidos</p>
      </div>

      <div className="chat-box">
        <div className="chat-messages">
          {mensagens.map((msg, index) => {
            const mensagemAnterior = mensagens[index - 1];
            const mostrarSeparador =
              !mensagemAnterior || !mesmoDiaISO(mensagemAnterior.createdAt, msg.createdAt);

            return (
              <div key={msg._id}>
                {mostrarSeparador && (
                  <div className="chat-date-separator">
                    <span>{formatarSeparadorData(msg.createdAt)}</span>
                  </div>
                )}

                {msg.tipo === 'perda' ? (
                  <div className="chat-bubble-wrapper align-right">
                    <div className="chat-relato-card">
                      <span className="chat-relato-titulo">📋 Item perdido relatado</span>
                      {msg.itemPerdido?.imagem?.data && (
                        <img
                          className="chat-relato-imagem"
                          src={`data:${msg.itemPerdido.imagem.contentType};base64,${msg.itemPerdido.imagem.data}`}
                          alt={msg.itemPerdido.nome}
                        />
                      )}
                      <strong>{msg.itemPerdido?.nome}</strong>
                      {msg.itemPerdido?.descricao && <p>{msg.itemPerdido.descricao}</p>}
                      {msg.itemPerdido?.local && (
                        <span className="chat-relato-local">📍 {msg.itemPerdido.local}</span>
                      )}
                      <span className="chat-bubble-hora">{formatarHora(msg.createdAt)}</span>
                    </div>
                  </div>
                ) : (
                  <div
                    className={`chat-bubble-wrapper ${msg.remetenteRole === 'user' ? 'align-right' : 'align-left'}`}
                  >
                    <div className={`chat-bubble ${msg.remetenteRole === 'user' ? 'bubble-user' : 'bubble-admin'}`}>
                      {msg.remetenteRole === 'admin' && (
                        <span className="chat-bubble-autor">{msg.remetenteNome}</span>
                      )}
                      <p>{msg.conteudo}</p>
                      <span className="chat-bubble-hora">{formatarHora(msg.createdAt)}</span>
                    </div>
                  </div>
                )}
              </div>
            );
          })}

          {aguardandoResposta && (
            <div className="chat-aguardando">
              <span>⏳</span>
              <p>Aguardando a resposta do reponsável...</p>
            </div>
          )}

          <div ref={fimRef} />
        </div>

        {chatLiberado ? (
          <form className="chat-input-bar" onSubmit={enviarMensagem}>
            <input
              type="text"
              placeholder="Digite sua mensagem..."
              value={texto}
              onChange={(e) => setTexto(e.target.value)}
            />
            <button type="submit" disabled={enviando || !texto.trim()}>
              Enviar
            </button>
          </form>
        ) : (
          <div className="chat-bloqueado">
            <span>🔒 Você poderá enviar mensagens assim que o responsável responder</span>
          </div>
        )}
      </div>
    </div>
  );
}

export default UserMensagens;