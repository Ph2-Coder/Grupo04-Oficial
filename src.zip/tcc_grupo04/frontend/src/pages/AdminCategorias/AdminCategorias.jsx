import { useState, useEffect } from 'react';
import axios from 'axios';
import ConfirmModal from '../../components/ConfirmModal/ConfirmModal';
import './AdminCategorias.css';

function AdminCategorias() {
  const [categorias, setCategorias] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState('');
  const [novaCategoria, setNovaCategoria] = useState('');
  const [salvando, setSalvando] = useState(false);
  const [categoriaParaExcluir, setCategoriaParaExcluir] = useState(null);

  useEffect(() => {
    buscarCategorias();
  }, []);

  const buscarCategorias = async () => {
    setCarregando(true);
    setErro('');
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:5000/api/categories', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setCategorias(response.data);
    } catch (err) {
      setErro(err.response?.data?.message || 'Erro ao buscar categorias.');
    } finally {
      setCarregando(false);
    }
  };

  const handleCriar = async (e) => {
    e.preventDefault();
    if (!novaCategoria.trim()) return;

    setSalvando(true);
    setErro('');
    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(
        'http://localhost:5000/api/categories',
        { nome: novaCategoria.trim() },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setCategorias([...categorias, response.data].sort((a, b) => a.nome.localeCompare(b.nome)));
      setNovaCategoria('');
    } catch (err) {
      setErro(err.response?.data?.message || 'Erro ao criar categoria.');
    } finally {
      setSalvando(false);
    }
  };

  const confirmarExclusao = async () => {
    if (!categoriaParaExcluir) return;

    try {
      const token = localStorage.getItem('token');
      await axios.delete(`http://localhost:5000/api/categories/${categoriaParaExcluir._id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setCategorias(categorias.filter((c) => c._id !== categoriaParaExcluir._id));
    } catch (err) {
      alert(err.response?.data?.message || 'Erro ao excluir categoria.');
    } finally {
      setCategoriaParaExcluir(null);
    }
  };

  return (
    <div>
      <div className="cat-header">
        <h1>Categorias</h1>
        <span className="total-badge">{categorias.length} categoria(s)</span>
      </div>

      <form className="cat-form" onSubmit={handleCriar}>
        <input
          type="text"
          placeholder="Nome da nova categoria"
          value={novaCategoria}
          onChange={(e) => setNovaCategoria(e.target.value)}
        />
        <button type="submit" className="btn-primary" disabled={salvando || !novaCategoria.trim()}>
          {salvando ? 'Adicionando...' : '+ Adicionar'}
        </button>
      </form>

      {erro && <p className="erro-msg">{erro}</p>}
      {carregando && <p className="status-msg">Carregando categorias...</p>}

      {!carregando && categorias.length === 0 && (
        <div className="cat-vazio">
          <span>🏷️</span>
          <p>Nenhuma categoria cadastrada ainda.</p>
        </div>
      )}

      {!carregando && categorias.length > 0 && (
        <div className="cat-lista">
          {categorias.map((c) => (
            <div className="cat-item" key={c._id}>
              <span>🏷️ {c.nome}</span>
              <button
                className="cat-btn-excluir"
                onClick={() => setCategoriaParaExcluir(c)}
              >
                🗑
              </button>
            </div>
          ))}
        </div>
      )}

      {categoriaParaExcluir && (
        <ConfirmModal
          titulo="Excluir categoria"
          mensagem={`Tem certeza que deseja excluir a categoria "${categoriaParaExcluir.nome}"?`}
          textoConfirmar="Excluir"
          perigo={true}
          onConfirmar={confirmarExclusao}
          onCancelar={() => setCategoriaParaExcluir(null)}
        />
      )}
    </div>
  );
}

export default AdminCategorias;