import { useState, useEffect } from 'react';
import { Navigate, useNavigate } from 'react-router-dom';
import { LayoutGrid, Package, Search, MessageCircle, Info } from 'lucide-react';
import image from '../../assets/image.png';
import ThemeToggle from '../../components/ThemeToggle/ThemeToggle';
import '../../components/Sidebar/Sidebar.css';
import '../../layouts/AdminLayout.css';
import '../AdminDashboard/AdminDashboard.css';
import './Landing.css';

const menuItems = [
  { label: 'Painel', icon: LayoutGrid, ativo: true },
  { label: 'Itens', icon: Package },
  { label: 'Busca', icon: Search },
  { label: 'Mensagens', icon: MessageCircle }
];

// Retorna o usuário logado ou null (se não houver sessão válida)
function lerSessao() {
  try {
    const token = localStorage.getItem('token');
    const usuario = JSON.parse(localStorage.getItem('usuario'));
    return token && usuario ? usuario : null;
  } catch {
    return null;
  }
}

function Landing() {
  const navigate = useNavigate();
  const [modalAberto, setModalAberto] = useState(false);
  const sessao = lerSessao();

  // Fecha a janela com a tecla Esc
  useEffect(() => {
    if (!modalAberto) return;

    const handleKey = (e) => {
      if (e.key === 'Escape') setModalAberto(false);
    };

    document.addEventListener('keydown', handleKey);
    return () => document.removeEventListener('keydown', handleKey);
  }, [modalAberto]);

  // Quem já está logado vai direto para o próprio painel
  if (sessao) {
    return <Navigate to={sessao.role === 'admin' ? '/admin' : '/home'} replace />;
  }

  const abrirModal = () => setModalAberto(true);

  const irPara = (rota) => (e) => {
    e.stopPropagation();
    navigate(rota);
  };

  return (
    <>
      {/* Qualquer clique nesta área abre a janela de login/cadastro */}
      <div className="admin-layout landing" onClick={abrirModal}>
        {/* Barra superior: só aparece no celular */}
        <header className="landing-topbar">
          <div className="landing-topbar-marca">
            <img src={image} alt="" />
            <strong>EtecampFinder</strong>
          </div>

          <div className="landing-topbar-acoes">
            <div onClick={(e) => e.stopPropagation()}>
              <ThemeToggle variante="icone" />
            </div>
            <button type="button" className="landing-btn" onClick={irPara('/login')}>
              Entrar
            </button>
            <button type="button" className="landing-btn" onClick={irPara('/register')}>
              Criar conta
            </button>
          </div>
        </header>

        <aside className="sidebar">
          <div className="sidebar-header">
            <img src={image} alt="Logo EtecampFinder" className="sidebar-logo" />
            <div>
              <h3>EtecampFinder</h3>
              <span>Sistema Escolar</span>
            </div>
          </div>

          <nav className="sidebar-nav">
            {menuItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.label}
                  type="button"
                  className={`sidebar-link landing-link ${item.ativo ? 'active' : ''}`}
                >
                  <span className="sidebar-icon">
                    <Icon size={20} strokeWidth={2} />
                  </span>
                  {item.label}
                </button>
              );
            })}
          </nav>

          <div className="sidebar-footer">
            <div className="sidebar-user">
              <div className="sidebar-avatar">V</div>
              <div>
                <strong>Visitante</strong>
                <span>Sem login</span>
              </div>
            </div>

            <div onClick={(e) => e.stopPropagation()}>
              <ThemeToggle />
            </div>

            <div className="landing-footer-acoes">
              <button type="button" className="landing-btn landing-btn-block" onClick={irPara('/login')}>
                Entrar
              </button>
              <button type="button" className="landing-btn landing-btn-block" onClick={irPara('/register')}>
                Criar conta
              </button>
            </div>
          </div>
        </aside>

        <div className="admin-layout-content">
          <div className="landing-aviso">
            <Info size={18} strokeWidth={2} />
            <span>
              Você está navegando como visitante. Clique em qualquer lugar para entrar ou criar sua conta.
            </span>
          </div>

          <div className="dashboard">
            <div className="dashboard-header">
              <img src={image} alt="" className="landing-hero-logo" />
              <div>
                <h1>Bem-vindo ao EtecampFinder</h1>
                <p>Acompanhe os objetos perdidos e achados da escola.</p>
              </div>
            </div>

            <div className="dashboard-cards dashboard-cards-single">
              <div className="dashboard-card">
                <div className="dashboard-card-top">
                  <span>Itens Devolvidos</span>
                  <div className="dashboard-card-icon" style={{ backgroundColor: '#d1fae5' }}>
                    ✅
                  </div>
                </div>
                <strong>—</strong>
              </div>
            </div>

            <div className="dashboard-recent">
              <div className="dashboard-recent-header">
                <h2>Itens Recentes</h2>
              </div>

              <div className="dashboard-itens-recentes">
                {[0, 1, 2].map((i) => (
                  <div className="dashboard-item-mini dashboard-item-mini-vazio" key={i}>
                    <span className="dashboard-item-mini-vazio-icon">📦</span>
                    <span>Entre para ver</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="landing-cta">
              <h2>Perdeu algo na escola?</h2>
              <p>Crie sua conta para acompanhar os itens devolvidos e falar com os reponsáveis pelos achados e perdidos.</p>
              <div className="landing-cta-acoes">
                <button type="button" className="landing-btn" onClick={irPara('/register')}>
                  Criar conta
                </button>
                <button type="button" className="landing-btn" onClick={irPara('/login')}>
                  Entrar
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* A janela fica fora da área clicável, para o clique de fechar não reabri-la */}
      {modalAberto && (
        <div className="landing-overlay" onClick={() => setModalAberto(false)}>
          <div
            className="landing-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="landing-modal-titulo"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              type="button"
              className="landing-modal-fechar"
              onClick={() => setModalAberto(false)}
              aria-label="Fechar"
            >
              ×
            </button>

            <img src={image} alt="" className="landing-modal-logo" />
            <h2 id="landing-modal-titulo">Entre para continuar</h2>
            <p>Para acessar essa área do EtecampFinder, faça login ou crie sua conta.</p>

            <div className="landing-modal-acoes">
              <button type="button" className="landing-btn" onClick={() => navigate('/login')}>
                Entrar
              </button>
              <button type="button" className="landing-btn" onClick={() => navigate('/register')}>
                Criar conta
              </button>
            </div>
          </div>
        </div>
      )}
    </>
  );
}

export default Landing;