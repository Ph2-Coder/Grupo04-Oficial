import { useState, useEffect } from 'react';
import axios from 'axios';
import ConfirmModal from '../../components/ConfirmModal/ConfirmModal';
import { getAvatarInfo } from '../../components/AvatarPickerModal/AvatarPickerModal';
import './AdminHome.css';

function AdminHome() {
  const [usuarios, setUsuarios] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState('');
  const [usuarioParaAlterar, setUsuarioParaAlterar] = useState(null);
  const [emailsVisiveis, setEmailsVisiveis] = useState({});
  const [filtroCategoria, setFiltroCategoria] = useState('Todos');

  useEffect(() => {
    buscarUsuarios();
  }, []);

  const buscarUsuarios = async () => {
    setCarregando(true);
    setErro('');
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:5000/api/users', {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });
      setUsuarios(response.data);
    } catch (err) {
      setErro(err.response?.data?.message || 'Erro ao buscar usuários.');
    } finally {
      setCarregando(false);
    }
  };

  const confirmarAlteracaoStatus = async () => {
    if (!usuarioParaAlterar) return;

    const novoStatus = !(usuarioParaAlterar.ativo !== false);

    try {
      const token = localStorage.getItem('token');
      await axios.put(
        `http://localhost:5000/api/users/${usuarioParaAlterar._id}/status`,
        { role: usuarioParaAlterar.role, ativo: novoStatus },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setUsuarios(usuarios.map((u) =>
        u._id === usuarioParaAlterar._id ? { ...u, ativo: novoStatus } : u
      ));
    } catch (err) {
      alert(err.response?.data?.message || 'Erro ao alterar status do usuário.');
    } finally {
      setUsuarioParaAlterar(null);
    }
  };

  const toggleEmail = (id) => {
    setEmailsVisiveis((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  const mascarar = (email) => {
    return '•'.repeat(Math.min(email.length, 12));
  };

  const formatarData = (dataISO) => {
    return new Date(dataISO).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  const usuariosFiltrados = usuarios.filter((u) => {
    if (filtroCategoria === 'Todos') return true;
    return u.categoria === filtroCategoria;
  });

  return (
    <div>
      <div className="admin-content-header">
        <h1>Usuários do Sistema</h1>
        <span className="total-badge">{usuariosFiltrados.length} usuário(s)</span>
      </div>

      <div className="itens-filtros">
        <select
          className="itens-filtro-status"
          value={filtroCategoria}
          onChange={(e) => setFiltroCategoria(e.target.value)}
        >
          <option value="Todos">Todas as categorias</option>
          <option value="Funcionário">Funcionário</option>
          <option value="Aluno">Aluno</option>
          <option value="Visitante">Visitante</option>
        </select>
      </div>

      {carregando && <p className="status-msg">Carregando usuários...</p>}
      {erro && <p className="erro-msg">{erro}</p>}

      {!carregando && !erro && (
        <div className="table-wrapper">
          <table className="users-table">
            <thead>
              <tr>
                <th>Avatar</th>
                <th>Nome</th>
                <th>E-mail</th>
                <th>Categoria</th>
                <th>Turma</th>
                <th>Status</th>
                <th>Cadastrado em</th>
                <th>Ações</th>
              </tr>
            </thead>
            <tbody>
              {usuariosFiltrados.map((u) => {
                const avatarInfo = getAvatarInfo(u.avatar);
                const estaAtivo = u.ativo !== false;
                return (
                  <tr key={u._id}>
                    <td>
                      <div
                        className="table-avatar"
                        style={avatarInfo ? { backgroundColor: avatarInfo.cor } : undefined}
                      >
                        {avatarInfo ? avatarInfo.emoji : u.nome.charAt(0).toUpperCase()}
                      </div>
                    </td>
                    <td>{u.nome}</td>
                    <td>
                      <div className="email-cell">
                        <span className="email-texto">
                          {emailsVisiveis[u._id] ? u.email : mascarar(u.email)}
                        </span>
                        <button
                          className="btn-olho"
                          onClick={() => toggleEmail(u._id)}
                          title={emailsVisiveis[u._id] ? 'Ocultar e-mail' : 'Mostrar e-mail'}
                        >
                          {emailsVisiveis[u._id] ? '🔒' : '👁'}
                        </button>
                      </div>
                    </td>
                    <td>
                      <span className={`role-badge ${u.role === 'admin' ? 'role-admin' : 'role-user'}`}>
                        {u.role === 'admin' ? 'Administrador' : 'Usuário'}
                      </span>
                    </td>
                    <td>
                      {u.turma ? (
                        <span className="detalhe-texto">{u.turma}</span>
                      ) : (
                        <span className="detalhe-texto vazio">—</span>
                      )}
                    </td>
                    <td>
                      <span className={`status-conta-badge ${estaAtivo ? 'status-conta-ativa' : 'status-conta-inativa'}`}>
                        {estaAtivo ? 'Ativo' : 'Inativo'}
                      </span>
                    </td>
                    <td>{u.createdAt ? formatarData(u.createdAt) : '-'}</td>
                    <td>
                      <button
                        className={estaAtivo ? 'btn-desativar-tabela' : 'btn-ativar-tabela'}
                        onClick={() => setUsuarioParaAlterar(u)}
                      >
                        {estaAtivo ? '✕ Desativar' : '✓ Ativar'}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {usuariosFiltrados.length === 0 && (
            <p className="status-msg">Nenhum usuário encontrado.</p>
          )}
        </div>
      )}

      {usuarioParaAlterar && (
        <ConfirmModal
          titulo={usuarioParaAlterar.ativo !== false ? 'Desativar usuário' : 'Ativar usuário'}
          mensagem={
            usuarioParaAlterar.ativo !== false
              ? `Tem certeza que deseja desativar "${usuarioParaAlterar.nome}"? Ele não poderá mais fazer login no sistema até ser reativado.`
              : `Tem certeza que deseja reativar "${usuarioParaAlterar.nome}"? Ele poderá voltar a fazer login normalmente.`
          }
          textoConfirmar={usuarioParaAlterar.ativo !== false ? 'Desativar' : 'Ativar'}
          perigo={usuarioParaAlterar.ativo !== false}
          onConfirmar={confirmarAlteracaoStatus}
          onCancelar={() => setUsuarioParaAlterar(null)}
        />
      )}
    </div>
  );
}

export default AdminHome;