import { useState, useEffect } from 'react';
import axios from 'axios';
import ItemModal from '../../components/ItemModal/ItemModal';
import ItemDetailModal from '../../components/ItemDetailModal/ItemDetailModal';
import logo from '../../assets/image.png';
import EventoToggle from '../../components/EventoToggle/EventoToggle';
import './AdminDashboard.css';

function AdminDashboard() {
  const usuario = JSON.parse(localStorage.getItem('usuario'));
  const [modalAberto, setModalAberto] = useState(false);
  const [itemSelecionado, setItemSelecionado] = useState(null);
  const [items, setItems] = useState([]);
  const [carregando, setCarregando] = useState(true);

  useEffect(() => {
    buscarItens();
  }, []);

  const buscarItens = async () => {
    setCarregando(true);
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:5000/api/items', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setItems(response.data);
    } catch (err) {
      console.error('Erro ao buscar itens:', err);
    } finally {
      setCarregando(false);
    }
  };

  const handleItemSalvo = (novoItem) => {
    setItems([novoItem, ...items]);
    setModalAberto(false);
  };

  const totalItens = items.length;
  const pendentes = items.filter((i) => i.status === 'Pendente').length;
  const devolvidos = items.filter((i) => i.status === 'Devolvido').length;
  const perdidos = items.filter((i) => i.tipo === 'Perdido').length;

  const cards = [
    { label: 'Total de Itens', valor: totalItens, icon: '📦', bg: '#eef2ff' },
    { label: 'Pendentes', valor: pendentes, icon: '⏰', bg: '#fef3c7' },
    { label: 'Devolvidos', valor: devolvidos, icon: '✅', bg: '#d1fae5' },
  ];

  const itensRecentes = items.slice(0, 3);
  // Preenche com "vazios" até completar 3 espaços, mesmo sem itens suficientes
  const espacos = [...itensRecentes, ...Array(Math.max(0, 3 - itensRecentes.length)).fill(null)];

  return (
    <div className="dashboard dashboard-cheio">
      <div className="dashboard-header">
        <div>
          <h1>Bem-vindo de volta, {usuario?.nome?.split(' ')[0]}</h1>
          <p>Gerencie objetos perdidos e achados na escola.</p>
        </div>
      </div>

      <div className="dashboard-cards">
        {cards.map((card, i) => (
          <div className="dashboard-card" key={i}>
            <div className="dashboard-card-top">
              <span>{card.label}</span>
              <div className="dashboard-card-icon" style={{ backgroundColor: card.bg }}>
                {card.icon}
              </div>
            </div>
            <strong>{card.valor}</strong>
          </div>
        ))}
      </div>

      <div className="dashboard-actions">
        <button className="btn-primary" onClick={() => setModalAberto(true)}>
          + Registrar Item
        </button>
      </div>

      <EventoToggle />

      <div className="dashboard-recent">
        <div className="dashboard-recent-header">
          <h2>Itens Recentes</h2>
        </div>

        {carregando && <p className="dashboard-empty">Carregando...</p>}

        {!carregando && (
          <div className="dashboard-itens-recentes">
            {espacos.map((item, i) =>
              item ? (
                <button
                  className="dashboard-item-mini"
                  key={item._id}
                  onClick={() => setItemSelecionado(item)}
                >
                  <div className="dashboard-item-mini-imagem">
                    {item.imagem?.data ? (
                      <img
                        src={`data:${item.imagem.contentType};base64,${item.imagem.data}`}
                        alt={item.nome}
                      />
                    ) : (
                      <span>📦</span>
                    )}
                  </div>
                  <div className="dashboard-item-mini-info">
                    <strong>{item.nome}</strong>
                    <span className={`status-badge ${item.status === 'Devolvido' ? 'status-devolvido' : 'status-pendente'}`}>
                      {item.status}
                    </span>
                  </div>
                </button>
              ) : (
                <div className="dashboard-item-mini dashboard-item-mini-vazio" key={`vazio-${i}`}>
                  <span className="dashboard-item-mini-vazio-icon">📦</span>
                  <span>Nenhum item</span>
                </div>
              )
            )}
          </div>
        )}
      </div>

      {modalAberto && (
        <ItemModal
          onClose={() => setModalAberto(false)}
          onItemSalvo={handleItemSalvo}
        />
      )}

      {itemSelecionado && (
        <ItemDetailModal
          item={itemSelecionado}
          onClose={() => setItemSelecionado(null)}
        />
      )}
    </div>
  );
}

export default AdminDashboard;