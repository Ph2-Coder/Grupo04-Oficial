import { useNavigate } from 'react-router-dom';
import './Home.css';

function Home() {
  const navigate = useNavigate();
  const usuario = JSON.parse(localStorage.getItem('usuario'));

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('usuario');
    navigate('/login');
  };

  return (
    <div className="home-container">
      <header className="home-header">
        <h2>Etecamp Finder</h2>
        <button className="logout-btn" onClick={handleLogout}>
          Sair
        </button>
      </header>

      <main className="home-content">
        <h1>Bem-vindo(a), {usuario?.nome}! 👋</h1>
        <p>Você está logado com o e-mail: {usuario?.email}</p>
      </main>
    </div>
  );
}

export default Home;