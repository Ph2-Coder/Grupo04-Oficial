import { useState, useEffect } from 'react';
import axios from 'axios';
import ConfirmModal from '../../components/ConfirmModal/ConfirmModal';
import '../AdminCategorias/AdminCategorias.css';

function AdminTurmas() {
  const [turmas, setTurmas] = useState([]);
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState('');
  const [novaTurma, setNovaTurma] = useState('');
  const [salvando, setSalvando] = useState(false);
  const [turmaParaExcluir, setTurmaParaExcluir] = useState(null);

  useEffect(() => {
    buscarTurmas();
  }, []);

  const buscarTurmas = async () => {
    setCarregando(true);
    setErro('');
    try {
      const response = await axios.get('http://localhost:5000/api/turmas');
      setTurmas(response.data);
    } catch (err) {
      setErro(err.response?.data?.message || 'Erro ao buscar turmas.');
    } finally {
      setCarregando(false);
    }
  };

  const handleCriar = async (e) => {
    e.preventDefault();
    if (!novaTurma.trim()) return;

    setSalvando(true);
    setErro('');
    try {
      const token = localStorage.getItem('token');
      const response = await axios.post(
        'http://localhost:5000/api/turmas',
        { nome: novaTurma.trim() },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      setTurmas([...turmas, response.data].sort((a, b) => a.nome.localeCompare(b.nome)));
      setNovaTurma('');
    } catch (err) {
      setErro(err.response?.data?.message || 'Erro ao criar turma.');
    } finally {
      setSalvando(false);
    }
  };

  const confirmarExclusao = async () => {
    if (!turmaParaExcluir) return;

    try {
      const token = localStorage.getItem('token');
      await axios.delete(`http://localhost:5000/api/turmas/${turmaParaExcluir._id}`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      setTurmas(turmas.filter((t) => t._id !== turmaParaExcluir._id));
    } catch (err) {
      alert(err.response?.data?.message || 'Erro ao excluir turma.');
    } finally {
      setTurmaParaExcluir(null);
    }
  };

  return (
    <div>
      <div className="cat-header">
        <h1>Turmas</h1>
        <span className="total-badge">{turmas.length} turma(s)</span>
      </div>

      <form className="cat-form" onSubmit={handleCriar}>
        <input
          type="text"
          placeholder="Nome da nova turma (ex. 3ºA - Informática)"
          value={novaTurma}
          onChange={(e) => setNovaTurma(e.target.value)}
        />
        <button type="submit" className="btn-primary" disabled={salvando || !novaTurma.trim()}>
          {salvando ? 'Adicionando...' : '+ Adicionar'}
        </button>
      </form>

      {erro && <p className="erro-msg">{erro}</p>}
      {carregando && <p className="status-msg">Carregando turmas...</p>}

      {!carregando && turmas.length === 0 && (
        <div className="cat-vazio">
          <span>🏫</span>
          <p>Nenhuma turma cadastrada ainda.</p>
        </div>
      )}

      {!carregando && turmas.length > 0 && (
        <div className="cat-lista">
          {turmas.map((t) => (
            <div className="cat-item" key={t._id}>
              <span>🏫 {t.nome}</span>
              <button
                className="cat-btn-excluir"
                onClick={() => setTurmaParaExcluir(t)}
              >
                🗑
              </button>
            </div>
          ))}
        </div>
      )}

      {turmaParaExcluir && (
        <ConfirmModal
          titulo="Excluir turma"
          mensagem={`Tem certeza que deseja excluir a turma "${turmaParaExcluir.nome}"?`}
          textoConfirmar="Excluir"
          perigo={true}
          onConfirmar={confirmarExclusao}
          onCancelar={() => setTurmaParaExcluir(null)}
        />
      )}
    </div>
  );
}

export default AdminTurmas;