import { useState, useEffect } from 'react';
import axios from 'axios';

const INTERVALO_MS = 30000; // confere o modo evento a cada 30 segundos
const EVENTO_ALTERADO = 'evento:alterado';

// Avisa o resto do sistema, na mesma hora, que o modo evento foi alterado
export function avisarEventoAlterado(eventoAtivo) {
  window.dispatchEvent(
    new CustomEvent(EVENTO_ALTERADO, { detail: { eventoAtivo } })
  );
}

// Informa se o modo evento está ativo e acompanha mudanças
export function useEvento() {
  const [eventoAtivo, setEventoAtivo] = useState(false);
  const [carregado, setCarregado] = useState(false);

  useEffect(() => {
    let montado = true;

    const buscar = async () => {
      try {
        const token = localStorage.getItem('token');
        const response = await axios.get('http://localhost:5000/api/config', {
          headers: { Authorization: `Bearer ${token}` }
        });

        if (montado) setEventoAtivo(!!response.data.eventoAtivo);
      } catch (err) {
        console.error('Erro ao buscar o modo evento:', err);
      } finally {
        if (montado) setCarregado(true);
      }
    };

    // Reage na hora quando o admin liga ou desliga o interruptor
    const aoAlterar = (e) => {
      if (montado) setEventoAtivo(!!e.detail?.eventoAtivo);
    };

    buscar();
    const intervalo = setInterval(buscar, INTERVALO_MS);
    window.addEventListener(EVENTO_ALTERADO, aoAlterar);

    return () => {
      montado = false;
      clearInterval(intervalo);
      window.removeEventListener(EVENTO_ALTERADO, aoAlterar);
    };
  }, []);

  return { eventoAtivo, carregado };
}