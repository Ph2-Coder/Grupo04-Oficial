import { useSyncExternalStore } from 'react';

const CHAVE = 'tema';
const ouvintes = new Set();

// Tema salvo; se nunca escolheu, segue a preferência do sistema operacional
function lerTemaInicial() {
  try {
    const salvo = localStorage.getItem(CHAVE);
    if (salvo === 'escuro' || salvo === 'claro') return salvo;
  } catch {
    // armazenamento indisponível: segue para a preferência do sistema
  }

  const prefereEscuro = window.matchMedia?.('(prefers-color-scheme: dark)').matches;
  return prefereEscuro ? 'escuro' : 'claro';
}

let temaAtual = lerTemaInicial();

function aplicar(tema) {
  const raiz = document.documentElement;

  if (tema === 'escuro') {
    raiz.setAttribute('data-theme', 'dark');
  } else {
    raiz.removeAttribute('data-theme');
  }
}

// Aplica já na carga do sistema, antes da primeira tela aparecer
aplicar(temaAtual);

export function definirTema(novoTema) {
  temaAtual = novoTema;
  aplicar(novoTema);

  try {
    localStorage.setItem(CHAVE, novoTema);
  } catch {
    // sem armazenamento: o tema vale só nesta sessão
  }

  ouvintes.forEach((avisar) => avisar());
}

export function alternarTema() {
  definirTema(temaAtual === 'escuro' ? 'claro' : 'escuro');
}

function assinar(avisar) {
  ouvintes.add(avisar);
  return () => ouvintes.delete(avisar);
}

function obterTema() {
  return temaAtual;
}

// Todos os botões de tema do sistema ficam sincronizados por este hook
export function useTema() {
  const tema = useSyncExternalStore(assinar, obterTema);

  return {
    tema,
    escuro: tema === 'escuro',
    alternar: alternarTema,
    definir: definirTema
  };
}