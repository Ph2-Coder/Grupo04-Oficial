import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'
import './styles/dark.css'
import './styles/responsivo.css' // sempre por último

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
  </StrictMode>,
)