import { useState, useEffect } from 'react';
import axios from 'axios';
import { getAvatarInfo } from '../AvatarPickerModal/AvatarPickerModal';
import './NovaConversaModal.css';

function NovaConversaModal({ onClose, onSelecionar }) {
  const [usuarios, setUsuarios] = useState([]);
  const [busca, setBusca] = useState('');
  const [carregando, setCarregando] = useState(true);
  const [erro, setErro] = useState('');

  useEffect(() => {
    buscarUsuarios();
  }, []);

  const buscarUsuarios = async () => {
    setCarregando(true);
    setErro('');
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:5000/api/users', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const apenasUsuarios = response.data.filter((u) => u.role === 'user');
      setUsuarios(apenasUsuarios);
    } catch (err) {
      setErro(err.response?.data?.message || 'Erro ao buscar usuários.');
    } finally {
      setCarregando(false);
    }
  };

  const usuariosFiltrados = usuarios.filter((u) =>
    u.nome.toLowerCase().includes(busca.toLowerCase()) ||
    u.email.toLowerCase().includes(busca.toLowerCase())
  );

  return (
    <div className="nc-overlay" onClick={onClose}>
      <div className="nc-box" onClick={(e) => e.stopPropagation()}>
        <div className="nc-header">
          <h2>Nova Conversa</h2>
          <button className="nc-close" onClick={onClose}>×</button>
        </div>

        <input
          type="text"
          className="nc-busca"
          placeholder="🔍 Buscar usuário..."
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
          autoFocus
        />

        <div className="nc-lista">
          {carregando && <p className="status-msg">Carregando...</p>}
          {erro && <p className="erro-msg">{erro}</p>}

          {!carregando && !erro && usuariosFiltrados.length === 0 && (
            <p className="status-msg">Nenhum usuário encontrado.</p>
          )}

          {usuariosFiltrados.map((u) => {
            const avatarInfo = getAvatarInfo(u.avatar);
            return (
              <button
                key={u._id}
                className="nc-item"
                onClick={() => onSelecionar({ userId: u._id, nome: u.nome, email: u.email, avatar: u.avatar })}
              >
                <div
                  className="nc-avatar"
                  style={avatarInfo ? { backgroundColor: avatarInfo.cor } : undefined}
                >
                  {avatarInfo ? avatarInfo.emoji : u.nome.charAt(0).toUpperCase()}
                </div>
                <div className="nc-info">
                  <strong>{u.nome}</strong>
                  <span>{u.email}</span>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export default NovaConversaModal;