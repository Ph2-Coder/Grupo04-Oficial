import { useState, useEffect } from 'react';
import axios from 'axios';
import ConfirmModal from '../ConfirmModal/ConfirmModal';
import { avisarEventoAlterado } from '../../hooks/useEvento';
import './EventoToggle.css';

function EventoToggle() {
  const [config, setConfig] = useState(null);
  const [carregando, setCarregando] = useState(true);
  const [salvando, setSalvando] = useState(false);
  const [erro, setErro] = useState('');
  const [confirmando, setConfirmando] = useState(false);

  useEffect(() => {
    buscarConfig();
  }, []);

  const cabecalho = () => ({
    headers: { Authorization: `Bearer ${localStorage.getItem('token')}` }
  });

  const buscarConfig = async () => {
    setCarregando(true);
    setErro('');
    try {
      const response = await axios.get('http://localhost:5000/api/config', cabecalho());
      setConfig(response.data);
    } catch (err) {
      setErro(err.response?.data?.message || 'Erro ao carregar o modo evento.');
    } finally {
      setCarregando(false);
    }
  };

  const ativo = !!config?.eventoAtivo;

  const confirmarAlteracao = async () => {
    setSalvando(true);
    setErro('');
    try {
      const response = await axios.put(
        'http://localhost:5000/api/config',
        { eventoAtivo: !ativo },
        cabecalho()
      );
      setConfig(response.data);
      avisarEventoAlterado(!!response.data.eventoAtivo);
    } catch (err) {
      setErro(err.response?.data?.message || 'Erro ao alterar o modo evento.');
    } finally {
      setSalvando(false);
      setConfirmando(false);
    }
  };

  const formatarDataHora = (dataISO) =>
    new Date(dataISO).toLocaleString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });

  return (
    <>
      <div className={`evento-card ${ativo ? 'ativo' : ''}`}>
        <div className="evento-texto">
          <div className="evento-titulo-linha">
            <h2 id="evento-titulo" className="evento-titulo">Modo evento</h2>
            <span className={`evento-estado ${ativo ? 'on' : 'off'}`}>
              {carregando ? 'Carregando...' : ativo ? 'Ativado' : 'Desativado'}
            </span>
          </div>

          <p className="evento-descricao">
            {ativo
              ? 'Os usuários estão vendo todos os itens registrados, inclusive os que ainda não foram devolvidos.'
              : 'Os usuários veem apenas os itens já devolvidos. Ative nos períodos de evento para liberar todos os itens.'}
          </p>

          {config?.atualizadoEm && (
            <p className="evento-meta">
              Última alteração{config.atualizadoPor ? ` por ${config.atualizadoPor}` : ''} em{' '}
              {formatarDataHora(config.atualizadoEm)}
            </p>
          )}

          {erro && <p className="evento-erro" role="alert">{erro}</p>}
        </div>

        <button
          type="button"
          role="switch"
          aria-checked={ativo}
          aria-labelledby="evento-titulo"
          className="evento-switch"
          onClick={() => setConfirmando(true)}
          disabled={carregando || salvando || !config}
        >
          <span className="evento-switch-bolinha" />
        </button>
      </div>

      {confirmando && (
        <ConfirmModal
          titulo={ativo ? 'Encerrar modo evento' : 'Ativar modo evento'}
          mensagem={
            ativo
              ? 'Ao encerrar, os usuários voltam a ver somente os itens já devolvidos.'
              : 'Ao ativar, todos os usuários poderão ver todos os itens registrados, inclusive os que ainda não foram devolvidos. Quem retirou cada item continua visível apenas para administradores.'
          }
          textoConfirmar={ativo ? 'Encerrar' : 'Ativar'}
          perigo={false}
          onConfirmar={confirmarAlteracao}
          onCancelar={() => setConfirmando(false)}
        />
      )}
    </>
  );
}

export default EventoToggle;