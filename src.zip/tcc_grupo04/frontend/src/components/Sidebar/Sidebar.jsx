import { useState, useEffect } from 'react';
import { NavLink, useNavigate, useLocation } from 'react-router-dom';
import { LogOut, Menu, X } from 'lucide-react';

import image from '../../assets/image.png';
import AvatarPickerModal, {
  getAvatarInfo
} from '../AvatarPickerModal/AvatarPickerModal';
import ThemeToggle from '../ThemeToggle/ThemeToggle';
import './Sidebar.css';

function Sidebar({ menuItems }) {
  const navigate = useNavigate();
  const location = useLocation();

  const [usuario, setUsuario] = useState(
    JSON.parse(localStorage.getItem('usuario'))
  );

  const [modalAvatarAberto, setModalAvatarAberto] = useState(false);
  const [menuAberto, setMenuAberto] = useState(false);

  // Fecha o menu ao trocar de página
  useEffect(() => {
    setMenuAberto(false);
  }, [location.pathname]);

  // Com o menu aberto: Esc fecha e a página de trás não rola
  useEffect(() => {
    if (!menuAberto) return;

    const aoPressionar = (e) => {
      if (e.key === 'Escape') setMenuAberto(false);
    };

    document.addEventListener('keydown', aoPressionar);
    const overflowAnterior = document.body.style.overflow;
    document.body.style.overflow = 'hidden';

    return () => {
      document.removeEventListener('keydown', aoPressionar);
      document.body.style.overflow = overflowAnterior;
    };
  }, [menuAberto]);

  // Se a janela voltar à largura de computador, garante o menu fechado
  useEffect(() => {
    const consulta = window.matchMedia('(min-width: 769px)');
    const aoMudar = (e) => {
      if (e.matches) setMenuAberto(false);
    };

    consulta.addEventListener('change', aoMudar);
    return () => consulta.removeEventListener('change', aoMudar);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('usuario');
    navigate('/login');
  };

  const handleAvatarSalvo = (novoAvatarId) => {
    const usuarioAtualizado = { ...usuario, avatar: novoAvatarId };

    localStorage.setItem(
      'usuario',
      JSON.stringify(usuarioAtualizado)
    );

    setUsuario(usuarioAtualizado);
    setModalAvatarAberto(false);
  };

  const avatarInfo = getAvatarInfo(usuario?.avatar);

  return (
    <>
      {/* Barra superior: só aparece no celular */}
      <header className="mobile-topbar">
        <button
          type="button"
          className="mobile-topbar-menu"
          onClick={() => setMenuAberto(true)}
          aria-label="Abrir menu"
          aria-expanded={menuAberto}
          aria-controls="menu-lateral"
        >
          <Menu size={24} strokeWidth={2} />
        </button>

        <img src={image} alt="" className="mobile-topbar-logo" />
        <strong className="mobile-topbar-titulo">EtecampFinder</strong>
      </header>

      {/* Fundo escuro atrás do menu aberto (só no celular) */}
      <div
        className={`sidebar-backdrop ${menuAberto ? 'visivel' : ''}`}
        onClick={() => setMenuAberto(false)}
        aria-hidden="true"
      />

      <aside
        id="menu-lateral"
        className={`sidebar ${menuAberto ? 'sidebar-aberta' : ''}`}
      >
        <div className="sidebar-header">
          <img
            src={image}
            alt="Nossa logo"
            className="sidebar-logo"
          />

          <div>
            <h3>EtecampFinder</h3>
            <span>Sistema Escolar</span>
          </div>

          <button
            type="button"
            className="sidebar-fechar"
            onClick={() => setMenuAberto(false)}
            aria-label="Fechar menu"
          >
            <X size={22} strokeWidth={2} />
          </button>
        </div>

        <nav className="sidebar-nav">
          {menuItems.map((item) => {
            const Icon = item.icon;

            return (
              <NavLink
                key={item.path}
                to={item.path}
                end={item.end}
                onClick={() => setMenuAberto(false)}
                className={({ isActive }) =>
                  isActive
                    ? 'sidebar-link active'
                    : 'sidebar-link'
                }
              >
                <span className="sidebar-icon">
                  <Icon size={20} strokeWidth={2} />
                </span>

                {item.label}
              </NavLink>
            );
          })}
        </nav>

        <div className="sidebar-footer">
          <div className="sidebar-user">
            <button
              className="sidebar-avatar"
              style={
                avatarInfo
                  ? { backgroundColor: avatarInfo.cor }
                  : undefined
              }
              onClick={() => setModalAvatarAberto(true)}
              title="Alterar foto de perfil"
            >
              {avatarInfo
                ? avatarInfo.emoji
                : usuario?.nome?.charAt(0).toUpperCase()}
            </button>

            <div>
              <strong>{usuario?.nome}</strong>
              <span>
                {usuario?.role === 'admin'
                  ? 'Administrador'
                  : 'Usuário'}
              </span>
            </div>
          </div>

          <ThemeToggle />

          <button
            className="sidebar-logout"
            onClick={handleLogout}
          >
            <LogOut size={20} strokeWidth={2} />
            <span>Sair</span>
          </button>
        </div>
      </aside>

      {modalAvatarAberto && (
        <AvatarPickerModal
          avatarAtual={usuario?.avatar}
          onClose={() => setModalAvatarAberto(false)}
          onSalvo={handleAvatarSalvo}
        />
      )}
    </>
  );
}

export default Sidebar;