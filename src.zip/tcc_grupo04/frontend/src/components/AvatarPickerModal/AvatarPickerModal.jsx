import { useState } from 'react';
import axios from 'axios';
import './AvatarPickerModal.css';

export const AVATARES = [
  { id: 'fox', emoji: '🦊', cor: '#fef3c7' },
  { id: 'cat', emoji: '🐱', cor: '#fce7f3' },
  { id: 'dog', emoji: '🐶', cor: '#fde68a' },
  { id: 'panda', emoji: '🐼', cor: '#e5e7eb' },
  { id: 'lion', emoji: '🦁', cor: '#fed7aa' },
  { id: 'koala', emoji: '🐨', cor: '#d1d5db' },
  { id: 'owl', emoji: '🦉', cor: '#e0e7ff' },
  { id: 'penguin', emoji: '🐧', cor: '#dbeafe' },
  { id: 'rabbit', emoji: '🐰', cor: '#fbcfe8' },
  { id: 'bear', emoji: '🐻', cor: '#fde68a' },
  { id: 'tiger', emoji: '🐯', cor: '#fed7aa' },
  { id: 'unicorn', emoji: '🦄', cor: '#f3e8ff' }
];

export function getAvatarInfo(avatarId) {
  return AVATARES.find((a) => a.id === avatarId) || null;
}

function AvatarPickerModal({ avatarAtual, onClose, onSalvo }) {
  const [selecionado, setSelecionado] = useState(avatarAtual || null);
  const [salvando, setSalvando] = useState(false);
  const [erro, setErro] = useState('');

  const handleSalvar = async () => {
    if (!selecionado) return;

    setSalvando(true);
    setErro('');
    try {
      const token = localStorage.getItem('token');
      await axios.put(
        'http://localhost:5000/api/users/avatar',
        { avatar: selecionado },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      onSalvo(selecionado);
    } catch (err) {
      setErro(err.response?.data?.message || 'Erro ao salvar avatar.');
    } finally {
      setSalvando(false);
    }
  };

  return (
    <div className="avatar-overlay" onClick={onClose}>
      <div className="avatar-box" onClick={(e) => e.stopPropagation()}>
        <div className="avatar-header">
          <h2>Escolha seu avatar</h2>
          <button className="avatar-close" onClick={onClose}>×</button>
        </div>

        <div className="avatar-grid">
          {AVATARES.map((av) => (
            <button
              key={av.id}
              className={`avatar-opcao ${selecionado === av.id ? 'selecionado' : ''}`}
              style={{ backgroundColor: av.cor }}
              onClick={() => setSelecionado(av.id)}
              type="button"
            >
              <span>{av.emoji}</span>
            </button>
          ))}
        </div>

        {erro && <p className="avatar-erro">{erro}</p>}

        <div className="avatar-actions">
          <button className="btn-secondary" onClick={onClose}>
            Cancelar
          </button>
          <button
            className="btn-primary"
            onClick={handleSalvar}
            disabled={salvando || !selecionado}
          >
            {salvando ? 'Salvando...' : 'Salvar'}
          </button>
        </div>
      </div>
    </div>
  );
}

export default AvatarPickerModal;