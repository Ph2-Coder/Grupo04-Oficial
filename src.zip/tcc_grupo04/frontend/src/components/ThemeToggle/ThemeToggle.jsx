import { Moon, Sun } from 'lucide-react';
import { useTema } from '../../theme/tema';
import './ThemeToggle.css';

// variante "sidebar": interruptor com texto, para o menu lateral
// variante "flutuante": botão redondo fixo no canto, para Login e Cadastro
// variante "icone": botão redondo comum, para a barra superior da página inicial
function ThemeToggle({ variante = 'sidebar' }) {
  const { escuro, alternar } = useTema();

  const icone = escuro
    ? <Moon size={20} strokeWidth={2} />
    : <Sun size={20} strokeWidth={2} />;

  if (variante === 'flutuante' || variante === 'icone') {
    return (
      <button
        type="button"
        className={variante === 'flutuante' ? 'tema-flutuante' : 'tema-icone'}
        onClick={alternar}
        aria-label="Modo escuro"
        aria-pressed={escuro}
        title={escuro ? 'Voltar ao modo claro' : 'Ativar modo escuro'}
      >
        {icone}
      </button>
    );
  }

  return (
    <button
      type="button"
      role="switch"
      aria-checked={escuro}
      className="tema-toggle"
      onClick={alternar}
    >
      <span className="tema-toggle-icone" aria-hidden="true">
        {icone}
      </span>
      <span className="tema-toggle-texto">Modo escuro</span>
      <span className="tema-switch" aria-hidden="true">
        <span className="tema-switch-bolinha" />
      </span>
    </button>
  );
}

export default ThemeToggle;