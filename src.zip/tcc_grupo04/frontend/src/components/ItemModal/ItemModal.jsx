import { useState, useEffect } from 'react';
import axios from 'axios';
import './ItemModal.css';

// Pares fixos: cada tipo tem um status correspondente
const STATUS_POR_TIPO = { Perdido: 'Pendente', Achado: 'Devolvido' };
const TIPO_POR_STATUS = { Pendente: 'Perdido', Devolvido: 'Achado' };

function ItemModal({ onClose, onItemSalvo, itemParaEditar }) {
  const modoEdicao = !!itemParaEditar;

  const [formData, setFormData] = useState({
    nome: '',
    descricao: '',
    tipo: 'Perdido',
    categoria: 'Outros',
    status: 'Pendente',
    local: '',
    dataRegistro: ''
  });
  const [imagem, setImagem] = useState(null);
  const [previewImagem, setPreviewImagem] = useState(null);
  const [erro, setErro] = useState('');
  const [salvando, setSalvando] = useState(false);
  const [categorias, setCategorias] = useState([]);

  // Data de hoje segundo o servidor (limite máximo do campo de data)
  const [dataServidor, setDataServidor] = useState('');

  // Usuário que retirou o item (só usado em modo edição)
  const [usuarios, setUsuarios] = useState([]);
  const [retiradoPorId, setRetiradoPorId] = useState('');

  // Com alguém em "Retirado por", tipo e status ficam travados em Achado / Devolvido
  const itemRetirado = !!retiradoPorId;

  useEffect(() => {
    buscarCategorias();
    buscarDataServidor();
  }, []);

  useEffect(() => {
    if (itemParaEditar) {
      setFormData({
        nome: itemParaEditar.nome || '',
        descricao: itemParaEditar.descricao || '',
        tipo: itemParaEditar.tipo || 'Perdido',
        categoria: itemParaEditar.categoria || 'Outros',
        status: itemParaEditar.status || 'Pendente',
        local: itemParaEditar.local || '',
        dataRegistro: itemParaEditar.dataRegistro
          ? new Date(itemParaEditar.dataRegistro).toISOString().split('T')[0]
          : ''
      });

      if (itemParaEditar.imagem?.data) {
        setPreviewImagem(`data:${itemParaEditar.imagem.contentType};base64,${itemParaEditar.imagem.data}`);
      }

      setRetiradoPorId(itemParaEditar.retiradoPor?.userId || '');
      buscarUsuarios();
    }
  }, [itemParaEditar]);

  const buscarDataServidor = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:5000/api/items/data-servidor', {
        headers: { Authorization: `Bearer ${token}` }
      });
      const hoje = response.data.hoje;
      setDataServidor(hoje);

      // Item novo: a data padrão é a de hoje no servidor
      if (!itemParaEditar) {
        setFormData((prev) => ({ ...prev, dataRegistro: hoje }));
      }
    } catch (err) {
      console.error('Erro ao buscar data do servidor:', err);
    }
  };

  const buscarCategorias = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:5000/api/categories', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setCategorias(response.data);
    } catch (err) {
      console.error('Erro ao buscar categorias:', err);
    }
  };

  const buscarUsuarios = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await axios.get('http://localhost:5000/api/users', {
        headers: { Authorization: `Bearer ${token}` }
      });
      setUsuarios(response.data);
    } catch (err) {
      console.error('Erro ao buscar usuários:', err);
    }
  };

  const handleChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  // Mudou o tipo -> o status acompanha
  const handleTipoChange = (e) => {
    const novoTipo = e.target.value;
    setFormData({ ...formData, tipo: novoTipo, status: STATUS_POR_TIPO[novoTipo] });
  };

  // Mudou o status -> o tipo acompanha
  const handleStatusChange = (e) => {
    const novoStatus = e.target.value;
    setFormData({ ...formData, status: novoStatus, tipo: TIPO_POR_STATUS[novoStatus] });
  };

  // Escolheu quem retirou -> trava em Achado / Devolvido
  const handleRetiradoPorChange = (e) => {
    const valor = e.target.value;
    setRetiradoPorId(valor);

    if (valor) {
      setFormData((prev) => ({ ...prev, tipo: 'Achado', status: 'Devolvido' }));
    }
  };

  const handleImagemChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setImagem(file);
      setPreviewImagem(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setErro('');

    if (!formData.nome.trim()) {
      setErro('O nome do item é obrigatório.');
      return;
    }

    if (dataServidor && formData.dataRegistro > dataServidor) {
      setErro('A data de registro não pode estar no futuro.');
      return;
    }

    setSalvando(true);
    try {
      const token = localStorage.getItem('token');
      const dataToSend = new FormData();
      Object.entries(formData).forEach(([key, value]) => {
        dataToSend.append(key, value);
      });
      if (imagem) {
        dataToSend.append('imagem', imagem);
      }

      if (modoEdicao) {
        if (retiradoPorId) {
          const usuarioSelecionado = usuarios.find((u) => u._id === retiradoPorId);
          if (usuarioSelecionado) {
            dataToSend.append('retiradoPor', JSON.stringify({
              userId: usuarioSelecionado._id,
              nome: usuarioSelecionado.nome,
              email: usuarioSelecionado.email,
              role: usuarioSelecionado.role
            }));
          }
        } else {
          dataToSend.append('retiradoPor', 'null');
        }
      }

      let response;
      if (modoEdicao) {
        response = await axios.put(
          `http://localhost:5000/api/items/${itemParaEditar._id}`,
          dataToSend,
          { headers: { Authorization: `Bearer ${token}` } }
        );
      } else {
        response = await axios.post(
          'http://localhost:5000/api/items',
          dataToSend,
          { headers: { Authorization: `Bearer ${token}` } }
        );
      }

      onItemSalvo(response.data);
      onClose();

    } catch (err) {
      setErro(err.response?.data?.message || 'Erro ao salvar item.');
    } finally {
      setSalvando(false);
    }
  };

  const categoriaForaDaLista =
    formData.categoria && !categorias.some((c) => c.nome === formData.categoria);

  return (
    <div className="modal-overlay" onClick={onClose}>
      <div className="modal-box" onClick={(e) => e.stopPropagation()}>
        <div className="modal-header">
          <h2>{modoEdicao ? 'Editar Item' : 'Registrar Novo Item'}</h2>
          <button className="modal-close" onClick={onClose}>×</button>
        </div>

        <form onSubmit={handleSubmit} className="modal-form">
          <label>Nome do Item</label>
          <input
            type="text"
            name="nome"
            value={formData.nome}
            onChange={handleChange}
            required
          />

          <label>Descrição</label>
          <textarea
            name="descricao"
            rows="3"
            value={formData.descricao}
            onChange={handleChange}
          />

          <div className="modal-row">
            <div>
              <label>Tipo</label>
              <select
                name="tipo"
                value={formData.tipo}
                onChange={handleTipoChange}
                disabled={!modoEdicao || itemRetirado}
              >
                <option value="Perdido">Perdido</option>
                <option value="Achado">Achado</option>
              </select>
            </div>
            <div>
              <label>Categoria</label>
              <select name="categoria" value={formData.categoria} onChange={handleChange}>
                {categoriaForaDaLista && (
                  <option value={formData.categoria}>{formData.categoria}</option>
                )}
                {categorias.map((cat) => (
                  <option key={cat._id} value={cat.nome}>
                    {cat.nome}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="modal-row">
            <div>
              <label>Status</label>
              <select
                name="status"
                value={formData.status}
                onChange={handleStatusChange}
                disabled={!modoEdicao || itemRetirado}
              >
                <option value="Pendente">Pendente</option>
                <option value="Devolvido">Devolvido</option>
              </select>
            </div>
            <div>
              <label>Data de Registro</label>
              <input
                type="date"
                name="dataRegistro"
                value={formData.dataRegistro}
                max={dataServidor || undefined}
                onChange={handleChange}
              />
            </div>
          </div>

          <label>Local</label>
          <input
            type="text"
            name="local"
            placeholder="ex. Biblioteca, 2º andar"
            value={formData.local}
            onChange={handleChange}
          />

          {modoEdicao && (
            <>
              <label>Retirado por</label>
              <select value={retiradoPorId} onChange={handleRetiradoPorChange}>
                <option value="">Ninguém retirou ainda</option>
                {usuarios.map((u) => (
                  <option key={u._id} value={u._id}>
                    {u.nome} ({u.email}){u.role === 'admin' ? ' — Administrador' : ''}
                  </option>
                ))}
              </select>
            </>
          )}

          <label>Imagem</label>
          <label className="upload-box">
            {previewImagem ? (
              <img src={previewImagem} alt="Preview" className="upload-preview" />
            ) : (
              <>
                <span className="upload-icon">⬆</span>
                <span>Clique para enviar uma imagem</span>
              </>
            )}
            <input
              type="file"
              accept="image/*"
              onChange={handleImagemChange}
              hidden
            />
          </label>

          {erro && <p className="modal-erro">{erro}</p>}

          <div className="modal-actions">
            <button type="button" className="btn-secondary" onClick={onClose}>
              Cancelar
            </button>
            <button type="submit" className="btn-primary" disabled={salvando}>
              {salvando ? 'Salvando...' : 'Salvar'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default ItemModal;