import { Link, useLocation } from 'react-router-dom';
import { CalendarDays } from 'lucide-react';
import { useEvento } from '../../hooks/useEvento';
import './EventoBannerAdmin.css';

function EventoBannerAdmin() {
  const { eventoAtivo } = useEvento();
  const { pathname } = useLocation();

  // No Painel, o cartão do Modo evento já mostra o estado
  const ehPainel = pathname.replace(/\/$/, '') === '/admin';

  if (!eventoAtivo || ehPainel) return null;

  return (
    <div className="evento-banner" role="status">
      <CalendarDays size={20} strokeWidth={2} aria-hidden="true" />

      <span className="evento-banner-texto">
        <strong>Modo evento ativado.</strong> A comunidade está vendo todos os itens,
        inclusive os que ainda não foram devolvidos.
      </span>

      <Link to="/admin" className="evento-banner-link">
        Gerenciar
      </Link>
    </div>
  );
}

export default EventoBannerAdmin;