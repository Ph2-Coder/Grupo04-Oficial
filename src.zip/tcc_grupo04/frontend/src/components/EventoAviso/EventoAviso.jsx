import { CalendarDays } from 'lucide-react';
import './EventoAviso.css';

function EventoAviso() {
  return (
    <div className="evento-aviso" role="status">
      <CalendarDays size={20} strokeWidth={2} aria-hidden="true" />
      <span>
        <strong>Período de evento.</strong> Todos os itens registrados estão visíveis,
        inclusive os que ainda não foram devolvidos.
      </span>
    </div>
  );
}

export default EventoAviso;