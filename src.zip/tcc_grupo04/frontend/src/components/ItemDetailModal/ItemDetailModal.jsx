import { useState } from 'react';
import ImageLightbox from '../ImageLightbox/ImageLightbox';
import './ItemDetailModal.css';

function ItemDetailModal({ item, onClose }) {
  const [imagemAberta, setImagemAberta] = useState(false);

  if (!item) return null;

  const usuarioLogado = JSON.parse(localStorage.getItem('usuario'));
  const ehAdmin = usuarioLogado?.role === 'admin';

  const imagemSrc = item.imagem?.data
    ? `data:${item.imagem.contentType};base64,${item.imagem.data}`
    : null;

  const formatarData = (dataISO) => {
    if (!dataISO) return '-';
    return new Date(dataISO).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric'
    });
  };

  return (
    <>
      <div className="detail-overlay" onClick={onClose}>
        <div className="detail-box" onClick={(e) => e.stopPropagation()}>
          <div className="detail-header">
            <h2>{item.nome}</h2>
            <button className="detail-close" onClick={onClose}>×</button>
          </div>

          {imagemSrc ? (
            <button
              type="button"
              className="detail-imagem detail-imagem-clicavel"
              onClick={() => setImagemAberta(true)}
              aria-label="Ampliar imagem"
            >
              <img src={imagemSrc} alt={item.nome} />
              <span className="detail-imagem-dica">🔍 Clique para ampliar</span>
            </button>
          ) : (
            <div className="detail-imagem">
              <span className="detail-sem-imagem">📦</span>
            </div>
          )}

          <div className="detail-status-row">
            <span className={`status-badge ${item.status === 'Devolvido' ? 'status-devolvido' : 'status-pendente'}`}>
              {item.status}
            </span>
            <span className="tag">{item.tipo}</span>
          </div>

          <div className="detail-campo">
            <span className="detail-label">Descrição</span>
            <p>{item.descricao || 'Sem descrição.'}</p>
          </div>

          <div className="detail-grid">
            <div className="detail-campo">
              <span className="detail-label">Categoria</span>
              <p>{item.categoria || '-'}</p>
            </div>
            <div className="detail-campo">
              <span className="detail-label">Local</span>
              <p>{item.local || '-'}</p>
            </div>
            <div className="detail-campo">
              <span className="detail-label">Data de Registro</span>
              <p>{formatarData(item.dataRegistro)}</p>
            </div>
            <div className="detail-campo">
              <span className="detail-label">Cadastrado em</span>
              <p>{formatarData(item.createdAt)}</p>
            </div>
          </div>

          {ehAdmin && item.retiradoPor?.nome && (
            <div className="detail-campo detail-retirado">
              <span className="detail-label">Retirado por</span>
              <p>
                {item.retiradoPor.nome}
                {item.retiradoPor.email ? ` (${item.retiradoPor.email})` : ''}
              </p>
            </div>
          )}
        </div>
      </div>

      {imagemAberta && imagemSrc && (
        <ImageLightbox
          src={imagemSrc}
          alt={item.nome}
          onClose={() => setImagemAberta(false)}
        />
      )}
    </>
  );
}

export default ItemDetailModal;