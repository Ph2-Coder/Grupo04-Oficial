import './AnimatedBackground.css';

function AnimatedBackground() {
  return (
    <div className="animated-bg">
      <div className="blob blob-1"></div>
      <div className="blob blob-2"></div>
      <div className="blob blob-3"></div>
    </div>
  );
}

export default AnimatedBackground;