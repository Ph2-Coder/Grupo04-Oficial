import { Navigate } from 'react-router-dom';

function AdminRoute({ children }) {
  const token = localStorage.getItem('token');
  const usuario = JSON.parse(localStorage.getItem('usuario'));

  if (!token) {
    return <Navigate to="/login" />;
  }

  if (usuario?.role !== 'admin') {
    return <Navigate to="/home" />;
  }

  return children;
}

export default AdminRoute;