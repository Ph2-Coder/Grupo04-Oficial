import './ConfirmModal.css';

function ConfirmModal({ titulo, mensagem, onConfirmar, onCancelar, textoConfirmar = 'Confirmar', perigo = false }) {
  return (
    <div className="confirm-overlay" onClick={onCancelar}>
      <div className="confirm-box" onClick={(e) => e.stopPropagation()}>
        <h3>{titulo}</h3>
        <p>{mensagem}</p>

        <div className="confirm-actions">
          <button className="btn-secondary" onClick={onCancelar}>
            Cancelar
          </button>
          <button
            className={perigo ? 'btn-perigo' : 'btn-primary'}
            onClick={onConfirmar}
          >
            {textoConfirmar}
          </button>
        </div>
      </div>
    </div>
  );
}

export default ConfirmModal;