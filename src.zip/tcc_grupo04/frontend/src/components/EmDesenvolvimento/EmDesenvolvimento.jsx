function EmDesenvolvimento({ titulo }) {
  return (
    <div>
      <h1 style={{ fontSize: '22px', color: '#111827', marginBottom: '16px' }}>
        {titulo}
      </h1>
      <div style={{
        background: '#fff',
        border: '1px solid #e5e7eb',
        borderRadius: '12px',
        padding: '60px 20px',
        textAlign: 'center',
        color: '#9ca3af'
      }}>
        <p>Esta seção ainda está em desenvolvimento 🚧</p>
      </div>
    </div>
  );
}

export default EmDesenvolvimento;